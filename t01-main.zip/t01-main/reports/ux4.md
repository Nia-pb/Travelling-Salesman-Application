# User Experience - Team *T01* 

The report summarizes user experience testing performed on the team's application.

Each developer should ask the user to accomplish one or more simple tasks while monitoring their efforts.  
The user should attempt to complete the tasks without any aid from the developer.
Use a pseudonym to identify the user below. 
Set a time limit and tasks for the user to perform.

 
### Tasks

Each user should complete the following tasks in 20 minutes.
Developers should not guide the user, but the user may ask for help as a last resort.  
Consider this a failure when it happens.  

1. Set the starting point as your current location. If you choose to allow location services do the following:
   - Click the three dots next to `My Trip`.
   - Click the home icon.
   - Allow location services.
2. Search for an airport you recognize.
    - Click in the search bar and type the airport.
    - Click the plus icon on a place to add it to your trip.
3. Add 2 places to your trip by either clicking on the map or add a location from your search results.
4. Switch to a different server, and add a new place to your trip on the new server.
   - At the bottom of the page, click `https://localhost:31401`.
   - Change the `URL:` to another valid server (ie `https://localhost:31419`).
      - Note: a URL is valid when a green checkmark is visible.
   - Once you select a valid URL, click the `Save` button.
   - Add a new place to your trip.
6. Clear the trip.
    - Click the three dots next to `My Trip`.
    - Click the trash can icon.
7. Repeat steps 1-4.
8. Search for another destination.
9. Clear the search results.
    - Click the `X` in the search bar.
10. Add places until there are at least 11 stops.
11. Click `T01 TRNG` to view the about page.
12. To return to the home page, click `T01 TRNG` again.
13. For the remaning time, please continue navigating the application as you see fit.

### Demographics

Age, nationality, and other background information can sometimes be helpful understanding the problems a user encountered.

| Pseudonym | Demographics |
| :--- | :--- |
| Glen (friend) | 20, Caucasian, Male, engineering major |
| Levi (friend) | 24, Caucasian, Male, Internet Provider |
| Erik (friend) | 21, Caucasian, Male, College Student |
| Chris (parent) | 51, Caucasian, Male, Analyst |
| Tony (friend) | 30, Caucasian, Male, Software Engineer |
| Milia (roommate) | 22, Caucasion, Female, college student |
| Dan (spouse) | 27, Caucasion, Male, Development Manager |


### Observations

Note the users interactions with the system for each of the tasks.
Record the success, failures, and problems the user encountered for each task.
Note any aid that wass given along with anything you notice from their use of the application.
Add issues to GitHub for any changes necessary to the system.

| Task | problem, aid, observation | hi/med/low | github#  |
| :--- | :--- | :---: | :---: | 
| 2 | Glen liked the search bar clear button, search button icon | N/A | N/A |
| 2 | Glen liked the search bar enter key feature | N/A | N/A |
| 4 | Glen noticed an issue with the display of the features not having commas sometimes | med | #262 |
| 12 | Glen liked Team's about page consistency of pictures | N/A | N/A |
| 13 | Glen liked the load and save trip UIs | N/A | N/A |
| 2 | Levi found the searchBar easy to navigate, scrolling down to more places was more user friendly | N/A | N/A |
| 2 | When searching for a couple places, Levi was not able to find certain locations (Database content possibly)| N/A | N/A |
| 11 | Without instructions, Levi said it was a little confusing finding the home page | N/A | N/A |
| 13 | Levi liked how he can name his trip when saving, and different format options although he did not know what json was for | N/A | N/A |
| 1 | Erik liked how he could easily find the icon menu and make his selection from what's provided | N/A | N/A |
| 3 | Erik was not happy interacting with the map, such as zooming in and out and moving around, said that it was hard to scroll and not very responsive from what he is used to (could this be fixed?) | N/A | N/A |
| 4 | Erik liked to be given an alert when an server was invalid | N/A | N/A |
| 2 | Erik was a little frustrated when he couldn't find places he desired (starbucks, shell, malls, etc.) "Just Airports!!??" | N/A | N/A |
| 11 | Erik started laughing at the bitmojis | N/A | N/A |
| 11 | Erik mispronounced team name | low | #499 |
| 1 | Erik stated that without clear instructions it would be hard to find/set his current location | N/A | N/A |
| 1 | Erik never asked for help while completing the tasks | N/A | N/A |
| 2 | Tony had a little trouble finding the airports he was looking for using the search feature | N/A | N/A |
| 11 | Tony would like a high level summary of the trip (maybe right below the map?) | N/A | N/A |
| 11 | Tony did not like that there are two destinations when clicking the logo vs. the icon on the top of the page | N/A | N/A |
| 13 | Tony tried the load trip and save trip features and they both worked well | N/A | N/A |
| 13 | Tony said we should set our default file type for load trip through a cookie instead of the checkbox | N/A | N/A |
| 1 | Chris would like a text popup when he hovers his mouse over the itinerary buttons (such as the current location one) | N/A | N/A |
| 13 | Chris was able to swtich servers with no issues | N/A | N/A |
| 10 | Chris thought the process of adding trips was easy and intuitive | N/A | N/A |
| 13 | Chris would have liked the load/save trip buttons to be labeled | N/A | N/A |
| 14 | Milia liked search bar layout | N/A | N/A |
| 15 | Milia found it hard to tell what country or state each place was in | low | #497 |
| 16 | Milia could not find Denver airport without typing "Denver International" | low | #496 |
| 17 | Milia thought it should be easier to find airports she recognized, and to have them pop up first | med | #496 |
| 1 | Dan noticed, once the website was put in mobile view, the kabob next to `My Trip` was not aligned to the far right | low | #503 |
| 2 | Dan stated that the search results should be separated from the map | low | #504  |
| 2 | While Dan was searching for an airport, Elita observed that the search did work for a noticible airport if the search was exact (ie Denver International) | N/A | N/A |
| 3 | While observing Dan, the task instructions should be changed to specify serach results are airports, heliports, etc. | med | #505  |
| 4 | Dan noticed clicking the plus icon in search results multiple times resulted in the same location being duplicated | hi | #506  |
| N/A | Dan noticed that the kabobs next to `My Trip` and in the itinerary have significate whitespace that should be removed | low | #507  |
| N/A | Dan recommended when users click the trash icon to clear `My Trip` it should have a pop-up to confirm clearing the full trip, to be more clear for the user | low | #508  |
