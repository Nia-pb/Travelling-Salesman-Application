# Sprint 2 - t01 - TRNG

## Goal
### *Find places to go.*

## Sprint Leader: 
### Nik Torraca

## Definition of Done

* The Increment release for `v2.x` created as a GitHub Release and deployed on black-bottle under SPRINT.
* The design document (`design.md`) is updated.
* The sprint document (`sprint.md`) is updated with scrums, completed metrics, review, and retrospective.

## Policies

### Mobile First Design
* Design for mobile, tablet, laptop, desktop in that order.
* Use ReactStrap for a consistent user experience (no HTML, CSS, style, etc.).

### Clean Code
* Code Climate maintainability of A.
* Minimize code smells and duplication.

### Test Driven Development
* Write the tests before the code.
* Unit tests are fully automated.

### Processes
* Main is never broken. 
* All pull request builds and tests for Main are successful.
* All dependencies managed using Maven, npm, and WebPack.
* GitHub etiquette is followed always.


## Planned Epics

Epic 1 - Find Places:
The first epic our team will work to complete during this sprint is Find Places. For this epic, the user will use a search feature to find places to visit on their trip. The user has a couple of requests for this feature, including a list of places and their details that match what the user searched. The user will then be able to select one or more places to add to their trip. We expect completing this epic will be a challenge because it is our first epic with significant code changes, and everyone is unfamiliar with the class hierarchy. We plan on working the rest of this week to get it completed as soon as possible. Right now we have three tasks for the epic, inlcuding adding a search bar, adding a drop-down list of matching places, and select searched locations. As we get a little more familiar with this epic, we will add tasks that are more specific.

Epic 2 - Interoperability:
The second epic our team will be working on is the Interoperability epic. For this epic, our team will work to give the user the ability to use different services to plan their trip. The user will be able to click on the URL at the bottom of the webpage to display a popup that gives them a few options. They will be able to modify the URL, and click 'test' and the client will attempt to connect to the server that the user provided. If the client is unable to connect, the user can continue making changes to the URL or click the cancel button to quit. If the client is able to connect, a save button will replace the test button and the user can save their changes. We have three tasks for this epic right now, including adding a server test button, changing the test button to a save button, and creating a feature failure exception. Similarly to the first epic, we will add more tasks as we learn more.

Epic 3 - Where am I?:
The last epic we will complete is Where Am I. For this epic, the user will have the ability to enable location services and use a current location rather than the CSU Oval. For this epic we currently have two taks, setting up geolocation and setting that geolocation to the user's current location. More details about user interaction with this feature are coming soon.

## Metrics

| Statistic | # Planned | # Completed |
| --- | ---: | ---: |
| Epics | 3 | *count* |
| Tasks |  8   | *count* | 
| Story Points |  34  | *sum* | 

We know completing these epics will be a challenge, but we think we can do it. We are planning to get started a lot earlier than we did last sprint, so we can complete roughly one epic per week. 

## Scrums

| Date | Tasks closed  | Tasks in progress | Impediments |
| :--- | :--- | :--- | :--- |
| 9/13/2021 | *#91, #83 Create Sprint2.md and design.md* | *#87, #93, #102, #104, #105 Making updates to Sprint2.md and design.md* | None |
| 9/15/2021 | *#87, #93, #102, #104, #105, Making updates to Spring2.md and design.md* | *#109, Adding search bar* | Need to do more research | 
| 9/16/2021 | None | *#109, Adding search bar* | Need to continue our research |
| 9/17/2021 | *#109, Adding search bar* | *#123, 113, Set up TRNG API and add JSON schema* | Need to learn Postman and do research on APIs |
| 9/21/2021 | None | *#123, 113, Set up TRNG API and add JSON schema* | Continue our research/reading |
| 9/22/2021 | None | *#123, 113, Set up TRNG API and add JSON schema* | None |
| 9/23/2021 | *#113, Add JSON schema* | *#116, #124, Add FindRequest.java, TestFindRequest.java and FindPLaces.java* | None |
| 9/24/2021 | *#116, #124, #123 Add FindRequest.java, TestFindRequest.java and FindPlaces.java as well as set up TRNG API* | *#126, Get FindPlaces.java running by connecting to DB* | Need to get connection to DB working |
| 9/28/2021 | None | *#126, Get FindPlaces.java running by connecting to DB* | Need to get connection to DB working |
| 9/29/2021 | *#126, Get FindPlaces.java running by connecting to DB* | *#xxx, Make search bar functional with client updates* |  |


## Review

### Epics completed

### Epics not completed

Epic 1 - Find Places
Epic 2 - Interoperability
Epic 3 - Where Am I?

## Retrospective

### Things that went well

As a team, we did a great job meeting regularly and working on our tasks. We got together at least 4 times a week for about 4-5 hours each time. Everyone worked as a team, helping eachother out and staying focused and commited for a large duration each week. We were also much improved working with the technology that is used in this class (Docker, VSCode, Git/Github, Postman, etc.) This prevented much of the environment related setbacks we experienced in the first sprint. 

### Things we need to improve

We need to work on getting our Epics completed faster. We spent a lot of time in this sprint conducting research, and we did not manage to complete an Epic before the sprint deadline (We were very close to finishing Find Places). This was not due to lack of effort or time, but we definitely need to find a way to get more tasks completed next sprint. 

### One thing we will change next time

Our focus for the next sprint will be completing Epics/Tasks much quicker. To do this, we will do a much better job breaking the Epics down into smaller and simpler tasks. We also plan on finishing our sprint reading earlier (Before the sprint starts if possible).


