# Inspection - Team *T01* 

The goal of an Inspection is to find defects.
We first identify the code we wish to inspect, determine the time we wish to meet, and determine the checklist we will use to find faults in our code during the preparation before the meeting.

|  | Details |
| ----- | ----- |
| Subject | *LoadModal.js & LoadIO.js* |
| Meeting | *Saturday, November 27, 8:00 PM, Microsoft Teams* |
| Checklist | *[Inspection Checklist](https://github.com/CSU-CS-314-Fall-2021/t01/blob/9a9a6766467520cf29f89f1e959882077c398726/reports/checklist.md)* |

### Roles

We note the amount of time each person spent reviewing the code in preparation for the meeting.

| Name | Preparation Time |
| ---- | ---- |
| Nik | 35 mins |
| Johnny | 40 mins |
| Nicholas | 45 mins |
| Maya | 50 mins |
| Elita | 35 mins |
| Nia | 40 mins |


### Problems found

We list each potential defect we found in the code during our preparation so we can discuss them in the meeting.
We add a GitHub issue for each defect that requires a modification to the system.

| file:line | problem | hi/med/low | who found | github# |
| --- | --- | :---: | :---: | --- |
| loadIO.js:64 | The parser parameter is passed to this function but it is not used. Do we need it? | low | Nik | #618 |
| loadIO.js:43 | The isValidTripJson function seems a little unecessary. Why not call isJsonResponseValid from isValidTripJsonFile? All of these functions with similar names gets a little confusing | low | Nik | N/A |
| loadIO | It doesn't look like we are checking if the CSV file is valid like we are for JSON. Is this something we should do? | low | Nik | N/A |
| LoadModal.js | Test coverage for LoadModal.js could be increased, although it already meets the 70% threshold we are looking for | low | Nik | N/A | 
| LoadIO.js:86 |  have "context" parameter before "{places, distances, tripJson}" to have parameters in right order | low | Johnny | N/A | 
| LoadIO.js:56 |  "err, file, input, reason" are declared but never used (do we have to keep these?) | low | Johnny, Nia | #619 |
| LoadIO.js:105 | Maybe be more descriptive in error logging message, such as stating that file must be either CSV or JSON| low | Johnny | N/A |
| loadIO.js:8 | Error handling results in any invaild files returning an error message that says the CSV was invalid, even if it was a different type. | med | Nicholas | #620 |
| loadIO.js:36, 18 | JSON.Parse is called multiple times when it could be optimized into one. | low | Nicholas | N/A |
| loadIO.js:98-106 | showMessage calls are very similar and could be moved into a generalized function. | med | Nicholas | N/A |
| LoadModal.js:48 | Implement checks on the incoming file. | med | Maya | #620 | 
| loadIO.js:16-45 | Swap isValidTripJSON with readJSON for easier readability. | low | Maya | #621 |
| loadIO.js:69 | Change variable name "index" to "key" or something more descriptive. | low | Maya | N/A |
| loadIO.js:8 | Unless implemented elsewhere, needs a case for the file being neither .json or .csv. | low | Maya, Nia | #620 |
| LoadIO.js:34-41 | The function isValidTripJsonFile is called before readJSON; it should be listed before readJSON for readability. | low | Elita, Nia | #621 |
| LoadModal.js:42-50 | The function ModalBodyDiv is called after onUpload and toggleModal; it should be listed at the end of the LoadModal.js file for readability. | low | Elita | #621 |
