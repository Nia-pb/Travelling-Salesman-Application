# Sprint 5 - *T01* - *TRNG*

## Goal
### *Release!*

## Sprint Leader: 
### *Elita Danilyuk*

## Definition of Done

* The Increment release for `v5.x` created as a GitHub Release and deployed on black-bottle under SPRINT.
* The design document (`design.md`) is updated.
* The sprint document (`sprint.md`) is updated with scrums, completed metrics, review, and retrospective.

## Policies

### Mobile First Design
* Design for mobile, tablet, laptop, desktop in that order.
* Use ReactStrap for a consistent user experience (no HTML, CSS, style, etc.).

### Clean Code
* Code Climate maintainability of A (technical debt ratio==0).
* Minimize code smells and duplication.
* Use Single Responsibility Principle.

### Test Driven Development
* Write the tests before the code.
* Unit tests are fully automated.
* Code coverage is 70%

### Processes
* Incremental development.  No big bangs.
* Main is never broken. 
* All pull request builds and tests for Main are successful.
* All dependencies managed using Maven, npm, and WebPack.
* GitHub etiquette is followed always.


## Planned Epics
'Shorter Trip' is the first epic we plan on completing. This epic will allow a user to see if a shorter trip exists between the destinations that were initially selected. Once the user selects the 'Shorter Trip' option, a newly rendered map will appear with a list of sorted destinations. Once this appears the user will have the ability to select the 'Shorter Trip' or keep their initially planned trip.

'User Experience' is an epic created to improve the clients experience. This epic has two main parts. First, we will consider previous recommendations from users during Sprint 4. Second, TRNG will survey users a second time to receive further feedback.

'Highlight Place' is a feature that will allow a user to 'highlight' a place by selecting it in the trip/itinerary list. This will make it visibly 'marked' on the screen for the user to see.

'Save Map' is a feature in response to the client's request to save the current map. The client will have the ability to save the map in SVG or KML file formats. These formats will then allow the client to view the trip in other applications/tools.

'Trip Name' is an epic in response to the client's request to edit their trip. This feature will allow the client to add a name to their trip. If the client decides to edit the trip name, it will auto-populate to the default name when saving a trip. The client will still be able to edit the trip name when saving the trip if they choose.


## Metrics

| Statistic | # Planned | # Completed |
| --- | ---: | ---: |
| Epics | *5* | *7* |
| Tasks |  *39*   | *81* | 
| Story Points |  *50*  | *105* | 


## Scrums

| Date | Tasks closed  | Tasks in progress | Impediments |
| :--- | :--- | :--- | :--- |
| *11/14* | *#245, #505, #507, #537, #538, #539, #540* | *N/A* | An epic was completed, but we did not do a release. We felt it was inappropriate to do a release because 'A Best of Sprint 4' is not due until 11/16. Our team did not want any UI changes completed after Sprint 4 to be voted on. |
| *11/15* | *#530, #503, #496* | *#531, #532, #533, #534* | Our team plans on discussing appropriate tasks for our planned epics. |
| *11/17* | *#533, #532, #531, #475, #534* | *#570, #571, #504, #572* | N/A |
| *11/29* | *#576, #577, #572, #573, #575, #353, #504, #586, #587, #555, #557, #598, #596, #597, #599, #611, #613, #581, #621* | *#564, # 354, #357, #473, #508* | Shorter trip was held back slightly while the team was trouble shooting how to pass a place as an object, rather than its address. We have found the solution to this impediment and are working to complete the shorter trip epic. |
| *12/01* | *#618, #508, #559, #569, #619*| *#564, #354, #357, #473, #453, #601, #600* | The team is still working on the algorithm for shorter trip. We plan on working on the API requests and client end while the algorithm is being worked on. |
| *12/06* | *#497, #564, #499, #506, #578, #635, #642, #643* | *#262, #554, #558, #354, #356, #357, #473, #453, #601, #600* | The team has completed the architecture for shorter trip, but is working on completing the code on both the server side and client side. |
| *12/08* | *#262, #554, #558, #354, #356, #357, #472, #473, #561, #562, #647, #651, #477, #560, #563, #653, #656, #657, #660* | *#661, #600, #601, #665, #666, #667* | The team is hard at work wrapping up a few tasks for two epics. |

## Review

### Epics completed
This sprint the team completed 7 epics: shorter trip, user experience, highlight place, save map, trip name, maps, and modify trip.


Trip Name was the first epic completed. Trip name was shortly completed after Sprint 4; the user is now able to edit their trip name. When a user edits the trip name that name will be the default name used if they choose to save their trip or map.

User Experience was the next epic that was finished. This epic was a combination of recommendations from users as well as other user interface changes recommended by different team members. Changes that were made include, but are not limited to: a confirmation pop-up when a full itinerary is deleted; features being separated by commas when a server is changed; the alignment of kabobs/ellipses in the itinerary; and a confirmation pop-up when a search result is added to a users trip.

Highlight Place was finished shortly after user experience. This epic now allows a user to click a place in their itinerary and it will highlight that location with a marker on their screen. When the location is selected it also highlights that location blue in their itinerary.

Maps was completed concurrently with highlight place. This epic includes a feature to change the type of map background. The user has the option to select different map layers. If the user hovers over the layers icon in the map component, different map layers appear, such as, StreetMap (default), WorldImagery, Bright, Topographic, and Dark (night mode).

Save Map was the next epic completed. The user is now able to save the current map trip in a SVG or KML file format. The user can save their map by selecting the save icon in the ellipse next to their trip name and selecting the desired file type. These formats allow the user to view their trip in other tools and applications.

Shorter Trip was finished next. Although this epic was more complex and took more time and resources for the team, it was successfully implemented. This epic allows a user to click a car icon in the ellipse next to their trip name. Once the icon is selected, the user can click 'Optimize' to optimize their trip. This shows the optimized trip on their map and itinerary and the user has the option to keep the optimized trip or to undo the change to revert the changes.

Modify Trip was the final epic that was completed. This epic includes a feature to allow the user to modify their trip. This epic allows the user to: select a new starting location, while maintaining the order of the remaining destinations; reverse the order of their itinerary; remove/delete individual destinations or delete their entire itinerary; and reorder individual destinations.

### Epics not completed 
N/A; all epics were completed.


## Retrospective

### Things that went well
We worked very well as a team together this sprint. At the beginning of this sprint, we implemented new processes to improve our workflow, communication, clarity, and the teams progression in development. With the exception of fall break, our team was able to meet on a regular basis. The team met together approximately 3 times a week while smaller teams met regularly to troubleshoot on epics and tasks together. This sprint, each team member worked on different aspects of code to improve their individual skills and learned from one another. The team was able to split up tasks and epics this sprint and through lots of hard work and persistance, the team was able to surpass the initially planned epics.

### Things we need to improve
This sprint was truly the best sprint the team has completed; it is hard to pick an area of improvement for the team. This being said, if we had to choose at least one thing the team could improve it would be having team members working on code simultaneously. For example, when a group is working on implementing code on the server side, other teammates could be working on the code on the client side. This issue did not interfere with any epics that needed to be completed, but we are aware this could improve future workflows.

### One thing we will change next time
Although this is the final sprint, if we were to continue, the one thing we would change would be working on related code in both the server and client side simultaneously.

