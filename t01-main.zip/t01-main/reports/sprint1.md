# Sprint 1 - *001* - *TRNG*

## Product Goal
### *The Product Goal is an easy-to-use mobile trip planning application that satisfies a global audience.*

## Sprint Goal
### *Set up team identification for the user*

## Scrum Master
### *Nia Bennabhaktula*

## Definition of Done

* The Increment release for `v1.0` created as a GitHub Release and deployed on black-bottle under SPRINT.
* The design document (`design.md`) is updated.
* The sprint document (`sprint1.md`) is updated with scrums, completed metrics, review, and retrospective.


## Policies

### Mobile First Design
* Design for mobile, tablet, laptop, desktop in that order.
* Use ReactStrap for a consistent user experience (no HTML, CSS, style, etc.).

### Clean Code

### Test Driven Development

### Processes
* Main is never broken. 
* All pull request builds and tests for Main are successful.
* All dependencies managed using Maven, npm, and WebPack.
* GitHub etiquette is followed always.


## Planned Epics

  This team plans to complete the Epic called Team Identification. We want to give ourselves enough time to complete 
  this Epic and fully understand the instructions. As of right now, it is not obvious to us how long the tasks contained within the Team Identification epic 
  will take us since none of us are familiar with Javascript, Restful API, or HTML. In order to complete Team Identification in a timely manner,
  we will need to familiarize ourselves with these tools.

## Metrics

These metrics reflect what was planned at the beginning of the sprint and what we actually completed by the end of the sprint.

| Statistic | # Planned | # Completed |
| --- | ---: | ---: |
| Epics | 2 | 1 |
| Tasks |  12   | 10 | 
| Story Points |  15  | 11 | 


## Scrums

This allows us to track our progress on tasks during the scrum.
The #*task* numbers refer to the issue numbers in GitHub.

| Date | Tasks closed  | Tasks in progress | Impediments |
| :--- | :--- | :--- | :--- |
| *9/8/2021* | #*none* | #*8,9,10* | *getting environment set up* | 
| *9/9/2021* | #*8, Set Team Name* | #*38, ...* | *none* | 
| *9/9/2021* | #*9, Set Team Number and Name on server* | #*37, ...* | *none* | 
| *9/9/2021* | #*10, Set Team Number and Name on client* | #*36, ...* | *none* |
| *9/9/2021* | #*30, Mission Statement* | #*32, ...* | *none* | 
| *9/9/2021* | #*31, Set Team Image* | #*35, ...* | *merging from terminal and updating main* | 
| *9/9/2021* | #*32,38,37,36,35, Add team bio and Image* | #*none* | *none* | 




## Review
  
  Even though there were many barriers that we came upon our sprint1 journey, we managed to use that to help us push through and complete almost all epics.

#### Epics completed
  
  We successfully managed to complete the team identification epic. Many tasks were completed while working under this epic such as setting the team’s on the browser tab by making changes to the HTML file. We set the team number and name on the server by making changes to ConfigRequest.java, and changed team name and number in client in constants.js.

#### Epics not completed
The only epic we did not complete was the 'About' epic. This epic consisted of nine tasks. Of the nine tasks, seven were completed. The completed tasks included creating a team image, a team mission statement, and adding each team member's image, name, and biography. The tasks that were not completed consisted of updating our design for the addition of the team and each member's information, as well as, creating and adding new components to support our new structure.

## Retrospective

#### Things that went well

As a group, we worked well together. We were able to meet twice a week and have Nik (our online teammate) on a Teams call with us the whole time. We were all able to complete the tasks that were assigned to each person at the beginning of the sprint. Additionally, we all made sure nobody was left behind, and did a good job of keeping everyone on the same page. 

Many of us struggled with setting up our environments to launch our team website. We spend a lot of time making sure that everybody was able to use a working environment. The team found success using Docker with VSCode.

#### Things that we need to improve

In the future, our team needs to be more diligent about starting our tasks and epics earlier in the sprint. Luckily, we spent a lot of this sprint setting up our environments, which hopefully will not be as much of an issue in future sprints. This way, we can start sooner, and get actual work done right off the bat. 

We all used Docker to get the website running on our machines. This worked, but in the future we would like to become comfortable working on our website remotely through the CS department machines. This will be valuable for us as a backup incase Docker does not work, and it will be very important for testing the changes we will make.

In the upcoming sprint we will also spend more time improving our GitHub skill and etiquette. We were occasionally unsure of how to use correct GitHub etiquette; we will become more confident correctly using GitHub for the next sprint.

#### One thing we will change next time

For the next sprint, we will start sooner. To make sure that we are productive early on, we will meet at least twice a week to work on tasks.