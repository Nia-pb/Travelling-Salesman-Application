# Sprint 3 - T01 - TRNG

## Goal
### We plan to finish Find Places, Interoperability, Where Am I, Distances, Load Trip, and Save Trip.

## Sprint Leader: 
### Maya Vitrano

## Definition of Done

* The Increment release for `v3.0` created as a GitHub Release and deployed on black-bottle under SPRINT.
* The design document (`design.md`) is updated.
* The sprint document (`sprint3.md`) is updated with scrums, completed metrics, review, and retrospective.

## Policies

### Mobile First Design
* Design for mobile, tablet, laptop, desktop in that order.
* Use ReactStrap for a consistent user experience (no HTML, CSS, style, etc.).

### Clean Code
* Code Climate technical debt ratio less than 3.
* Minimize code smells and duplication.

### Test Driven Development
* Write the tests before the code.
* Unit tests are fully automated.
* Code coverage is 70%

### Processes
* Incremental development.  No big bangs.
* Main is never broken. 
* All pull request builds and tests for Main are successful.
* All dependencies managed using Maven, npm, and WebPack.
* GitHub etiquette is followed always.


## Planned Epics
We plan to finish Find Places, Interoperability, Where Am I, Distances, Load Trip, and Save Trip. In our last sprint we did not finish any epics. 
Now that we know more, we will consistently work towards getting these epics done. We are going to split up the work so that two groups can work on code at the same time. Since we still need each other's help to progress, working in small teams will be more efficient than working completely as individuals. Our main focus this sprint will be *doing*.

Find Places is in the end stages of completion. Find Places will allow the user to search for different places. We are confident that we can finish Find Places once we connect the client and server.

We have broken up interoperability into 10 small tasks. This will significantly increase our ability to finish the epic quickly.
In Find Places, we did not break the tasks up enough to efficiently work through them, which is a large reason why we didn't finish it. We have confidence that we can finish Interoperability in a few days with the smaller tasks.

Where Am I should be quite straightforward for us. We have looked through the code base and researched geolocation in React to figure out exactly what needs to be done. Our tasks contain the instructions to add geolocation to our web server. The main challenge here will be figuring out how to move the map to the user's current location when they click the home button icon.

Distances will be more challenging for us, but with small/specific tasks we should be able to get it finished without too many hiccups. In order for us to get this done we will have to write code right off the bat, rather than researching and planning too much. Of course, research will be neccessary, but prioritizing getting code written will speed up the process for us. We will also rely on the TAs for this epic.

Load Trips will be challenging for us because we do not have experience with loading in user input. Like Distances, we will need to do some research, but we will prioritize writing code. When we get stuck, we will look to the TAs for help because they can give us specific guidance much faster than the internet can. 


## Metrics

| Statistic | # Planned | # Completed |
| --- | ---: | ---: |
| Epics | 6 | 4 |
| Tasks |  31   | 86 | 
| Story Points |  75 | 109 | 


## Scrums

| Date | Tasks closed  | Tasks in progress | Impediments |
| :--- | :--- | :--- | :--- |
| 10/5 | Sprint 3 Planning | Assigning tasks | Reading code base to figure out how to divide tasks | 
| 10/6 | Assigned tasks for Interoperability and Where Am I | Interoperability & Where Am I | Make sure we do the tasks we are assigned & not branch out too much
| 10/8 | Remove changes to geolocation.js | Where Am I and Interoperability | Adding a test case to geolocation and removing code duplicatons | 
| 10/13 | 97, 98, 99, 100, 101, 106, 155, 156, 157, 169, 170, 173, 174, 175, 177, 197, 198, 200, 202, 208, 218, 219, 222 | 203, 162, 159 | Writing test cases |
| 10/15 | 180, 168, 231 | 160, Distances | Interop not showing features |
| 10/18 | 179, 172, 171, 281, 275, 278, 265 | 284, pop-up window to take csv file in LoadTrip | Unclear instructions for LoadTrip |
 

## Review

### Epics completed  
In Sprint 3, we completed 4 epics. We finished Find Places, Where Am I, Interoperability, and Distances.
Find Places was completed shortly after sprint 3 began. Nia put the finishing touches on Find Places by making the search bar go after the user hits enter and by significantly shortening the search time. We got off to a slow start in the last sprint, so we had not finished Find Places. Luckily, it was promptly finished.

Where Am I was the next sprint. It was fairly straightforward and we finished this epic before the half sprint 3. Writing test for Where Am I went well. 

Interoperability was a little bit trickier and took us longer to finish. We struggled with trying to connect to other servers, and had a hard time displaying other servers' supported features. We did manage to finish in a timely manner.

For server-side in Distances, we really struggled with getting the formula written. It was a challenge to transfer it from the formula to JavaScript. We also struggled with how to get the distance between the last place and the first place. We were able to add the features successfully on the server and client. For the client, we successfully added a distances component, where we could get the distances array from the server. We also added the distances component to the UI.

### Epics not completed 

We did not finish LoadTrip or SaveTrip. We decided early on in the sprint that we would not have time to finish Save Trip and put it in the icebox. As for LoadTrip, we are quite close to having this finished. At the moment we have a button that takes in a file, and we are debugging the code that will parse the uploaded file into a JSON file, if necessary. The biggest hurdle will be displaying the result on the website as a trip. This will hopefully be completed promptly at the start of Sprint 4.

## Retrospective

### Things that went well
As a team, we did really well meeting regularly and working on our tasks. We got together at least 4 times a week. Each team-mate worked closely together and helped through troubleshooting. The team continued to improve their skills through supplemental resources. The team also got tasks done faster this sprint because we split up tasks on a lower level; this allowed easier task assignments as well.

### Things we need to improve
We need to utilize the TAs more. We can usually only meet near the end of the week, so to fix this we need to figure out our questions before Monday. We also need to start adding our completed tasks to the Scrum as we close them, so that it stays more organized. As always, we need to break up our tasks more in planning.

### One thing we will change next time
We will spend more time getting help from the TAs.
