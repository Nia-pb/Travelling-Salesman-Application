# Inspection - Team *T01* 

The goal of an Inspection is to find defects.
We first identify the code we wish to inspect, determine the time we wish to meet, and determine the checklist we will use to find faults in our code during the preparation before the meeting.

|  | Details |
| ----- | ----- |
| Subject | SearchBar.js and code relating to SearchBar in Planner.js and actions.js |
| Meeting | 10/14, 7:00pm, Teams call |
| Checklist | [Inspection Checklist for t01](https://github.com/CSU-CS-314-Fall-2021/t01/blob/main/reports/checklist.md) |

### Roles

We note the amount of time each person spent reviewing the code in preparation for the meeting.

| Name | Preparation Time |
| ---- | ---- |
| Maya |  50 mins    |
| Nia  |  30 mins    |
| Elita | 35 mins    |
| Johnny |  35 mins  |
| Nik   | 40 mins    |


### Problems found

We list each potential defect we found in the code during our preparation so we can discuss them in the meeting.
We add a GitHub issue for each defect that requires a modification to the system.

| file:line | problem | hi/med/low | who found | github#  |
| --- | --- | :---: | :---: | --- |
| SearchBar.js: 14-16, 32, 35 | Readability: Commented out code | low | Nik | 237 |
| SearchBar.js | Missing coresponding test cases | high | Nik | 245 |
| SearchBar.js: 34, 37, 38 | Bad variable name | low | Maya | 236 |
|  SearchBar.js: 34| Imporve search results performance | med | Nia | 242 |
| actions.js: 49-51, 66 | Readability: Commented out code | low | Nik | 239 |
| Planner.js: 15-18 | Readability: Commented out code | low | Nik | 238 |
| All | Incease test coverage to 70% | high | Maya | 243 |
| SearchBar.js: 18 | Remove unused parameter "e" | med | Maya | 241 |
| SearchBar.js: N/A | Add corresponding test case | high | Elita | 245 |
| actions.js: N/A | Add correspsonding test case | high | Elita | 246 |
