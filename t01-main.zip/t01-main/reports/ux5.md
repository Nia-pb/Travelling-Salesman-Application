# User Experience - Team *T01* 

The report summarizes user experience testing performed on the team's application.

Each developer should ask the user to accomplish one or more simple tasks while monitoring their efforts.  
The user should attempt to complete the tasks without any aid from the developer.
Use a pseudonym to identify the user below. 
Set a time limit and tasks for the user to perform.

 
### Tasks

Each user should complete the following tasks in 10 minutes.
Developers should not guide the user, but the user may ask for help as a last resort.  
Consider this a failure when it happens.  

1. Set the starting point as your current location. If you choose to allow location services do the following:
   - Click the three dots next to `My Trip`.
   - Click the home icon.
   - Allow location services.
      - *If there is a pop up stating `... wants to know your location` click the `Allow` button.*
2. Search for an airport/heliport.
    - Click in the search bar and type the airport.
    - Press the `Enter` key or the search icon to see the search results.
    - Click the plus icon on a place to add it to your trip.
3. Add 2 places to your trip by either clicking on the map or add a location from your search results.
4. Switch to a different server, and add a new place to your trip on the new server.
   - At the bottom of the page, click `https://localhost:31401`.
   - Change the `URL:` to another valid server (ie `https://localhost:31419`).
       - Note: a URL is valid when a green check-mark is visible.
   - Once you select a valid URL, click the `Save` button.
   - Add a new place to your trip.
5. Edit your trip name
    - Click `My Trip` next to the edit icon.
    - Press the `Enter` key when you are ready to save the trip name
6. Save your trip.
    - Click the three dots next to `My Trip`.
    - Click the save icon (the icon looks like a floppy disk). A modal will pop up.
    - If you wish, rename your trip and save it as a JSON or CSV file by clicking the dropdown menu next to your trip name.
    - Click the `Download` button.
7. Clear the trip.
    - Click the three dots next to `My Trip`.
    - Click the trash can icon.
8. Repeat steps 1-4.
9. Search for another destination.
10. Clear the search results.
    - Click the `X` in the search bar.
11. Add places until there are at least 11 stops.
12. Click `T01 TRNG` to view the about page.
13. To return to the home page, click the `Close` button or click `T01 TRNG` again.
14. Clear your current trip.
    - Click the three dots next to `My Trip`.
    - Click the trash can icon.
15. Upload your previously saved trip.
    - Click the three dots next to `My Trip`.
    - Click the upload icon (the icon that looks like a piece of paper with an arrow). A modal will pop up.
    - Drag your desired trip into the greyed area of the pop-up, where it states `Supports: *.csv, *.json`.
    - A green pop-up will appear stating, "Successfully loaded..."
16. For the remaining time, please continue navigating the application as you see fit.
    - Please note, the following items are features TRNG is implementing.
        - Calculating shorter trips. *This is the car icon next to the save a clear icons.*
        - Adding a pop-up to confirm a user would like to clear the trip.

### Demographics

Age, nationality, and other background information can sometimes be helpful understanding the problems a user encountered.

| Pseudonym | Demographics |
| :--- | :--- |
| Derek | 21, caucasian, college student |
| Colette | 26, caucasian, female, dental hygiene student |
| John | 21, caucasian, male, College student |
| Dawson | 20, hispanic, male, college student |
| Christine | 49, caucasian, female, elementary school teacher |
| Levi | 24, caucasion, male |



### Observations

Note the users interactions with the system for each of the tasks.
Record the success, failures, and problems the user encountered for each task.
Note any aid that wass given along with anything you notice from their use of the application.
Add issues to GitHub for any changes necessary to the system.

| Task | problem, aid, observation | hi/med/low | github#  |
| :--- | :--- | :---: | :---: | 
| 2 | Had a hard time finding an airport he recognized. | med | #78, #497 |
| 3 | Did not know where (what country/state) each places was. | med | #497 |
| N/A | Colette did not have any questions or recommendations through the checklist. No bugs were noticed during the survey. | N/A | N/A | 
| 11 | John would like to have a scroll feature where the places are added. He said he would like to look at the places and the map at the same time. | med | #635 | 
| 4 | Dawson did not understand what switching servers meant and how port numbers could be input. | N/A | N/A |
| 6 | Dawson liked how easy it was to save a trip and that the trip name corresponded to the default download file name. | N/A | N/A |
| 15 | Dawson liked how easy it was to upload a trip with the drag and drop area, where you can also click. | N/A | N/A |
| 2 | Christine was not able to find everything she searched for | N/A | N/A |
| 7 | Christine noticed the trip name does not reset to "My Trip" when you delete a named trip | N/A | N/A |
| 15 | Christine liked the Save/Load trip features | N/A | N/A |
| N/A | Levi really liked the UI experience and did not have many recommendations. He found the app user-friendly | N/A | N/A |
