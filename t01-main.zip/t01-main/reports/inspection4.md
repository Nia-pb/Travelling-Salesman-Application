# Inspection - Team *T01* 

The goal of an Inspection is to find defects.
We first identify the code we wish to inspect, determine the time we wish to meet, and determine the checklist we will use to find faults in our code during the preparation before the meeting.

|  | Details |
| ----- | ----- |
| Subject | SaveTrip.js |
| Meeting | 11/3, 6:30pm, Teams |
| Checklist | [Inspection Checklist for t01](https://github.com/CSU-CS-314-Fall-2021/t01/blob/main/reports/checklist.md)|

### Roles

We note the amount of time each person spent reviewing the code in preparation for the meeting.

| Name | Preparation Time |
| ---- | ---- |
| Maya | 35 min |
| Nicholas | 45 min |
| Nia | 30 min |
| Elita | 25 min |
| Nik | 30 min |
| Johnny | 30 min |

### Problems found

We list each potential defect we found in the code during our preparation so we can discuss them in the meeting.
We add a GitHub issue for each defect that requires a modification to the system.

| file:line | problem | hi/med/low | who found | github#  |
| --- | --- | :---: | :---: | --- |
| `saveTrip.js:1, 2, 4, 6` | A lot of unused imports. | low | Nicholas | 447 |
| `saveTrip.js:23, 25` | Unused/commented out code. | low | Nicholas, Maya | 447 |
| `saveTrip.js:38` | Remnant `console.log` from debug. | med | Nicholas | 447 |
| `saveTrip.js:48` | Arguments should be `props` not `...props`, pass in with `{otherThing, ...props}` when calling. | med | Nicholas | 448 |
| `saveTrip.js:57` | Unused/commented out code. | low | Nicholas, Maya | 447 |
| `saveTrip.js` | Remove unwanted code| low | Nia | 447 |
| `SaveModal.js` | Break down the code into smaller functions for readability as well as exceeding line limit | low | Nia | 450 |
| `actions.js:7, 9` | Unused import statement/File Format variable is being unused | low | Nia | 447 |
| `saveTrip.js:15` | Change function name from "SaveTrip" to "saveTrip" since it is not a component | low | Maya | |
| `saveTrip.js` | Need to add a test file and/or test cases for Save Trip	| high | Johnny, Nik | 384 |
| `saveTrip.js: 87` | Unused/commented out code | low | Johnny | 448 |
| `saveTrip.js:74, 87` | Unused/commented out code. | low | elita | 447 |

