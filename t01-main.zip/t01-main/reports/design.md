# Introduction

This document describes the architecture and design of a single page web application that interacts with microservices via RESTful APIs.
The key elements in this document include the architecture, user interface, client components, and server classes.

This is a living document that is updated as changes are made each sprint.
The initial document describes the Base code students are given as a starting point for the semester.
Students are expected to update this document as changes are made each sprint to reflect the evolution of their application and key decisions they make.
The Base section serves as an example.


# Base

The Base is a simple application to provide the architecture to the students at the beginning of the semester.
The JavaScript code will be useful examples for students to learn from and leverage in the code they write for sprint 1.
The progressive display of information using collapsible sections and popups will serve as examples of good user interface design.
The overall design is somewhat minimalist/simple for the intended mobile device audience.

### Architecture

The Base architecture is a JavaScript single page web application in an HTML5 browser that uses RESTful APIs to access Micro-services provided by a Java server running on Linux.
The client consists of a minimal index.html file that loads and executes the bundled JavaScript application.
The client and server files are bundled into a single JAR file for execution on the Linux server at a specified port.
The browser fetches the client files from the server on the specified port.

![overview](images/BaseArchitecture.png)

The browser loads the index.html file (by default) which in turn loads the bundled JavaScript single page application bundle.js.
* The single page application makes RESTful API requests to the server on the same port using  JavaScript's asynchronous fetch.  
* A protocol document describes the JSON format for the RESTful API requests and responses.
* JSON Schemas are used to verify requests on the server side and responses on the client side.
* On the client, ReactJS renders the application using ReactStrap, Leaflet, and application defined components.
* GSON is used on the server to convert JSON requests to Java objects and Java objects to JSON responses.
* The client (ulog) and server (SLF4J) logging mechanisms control debugging output during development and production - print statements and console logging should never be used. 

The following architecture elements are not included in the Base system.
They will be added later in the semester.
* Client filesystem.
* Server SQL.
* Server concurrency.


### User Interface
![base](images/Map.jpg)

The basic screen in black shows the view on a mobile device, with a header, footer, and trip.
The header contains a earth logo and the team name obtained from the server when the client was loaded.
The footer contains a connection icon along with the current server name and server URL the client is connected to.
The trip shows a map and the current list of destinations.

Rather than buttons or icons to signify actions, we are associating actions with elements that are already on the screen to reduce the clutter.
We are using both popups and collapsible sections in this design rather than choosing to use one exclusively.
* Collapsible/Hidden sections are used for the map and about sections since they have a significant amount of content and we don't need to see them at the same time.
* A popup is used for the URL change since we want to control the interaction until the operation is completed. It seemed more natural than another collapsible section.

#### Clicking on the team name in the header displays an empty about screen.
Clicking again restores the trip screen.
We will fill this in later.

#### Clicking on the map adds to the trip.
Whenever a user clicks on the map, the client should display a marker with latitude, longitude, and a description at that location.
The description is obtained from reverse geocoding.
The location information is also added to the trip list below the map.
We only maintain a single marker at this point displaying the most recently clicked location.

#### Clicking the hotdogs (&#8942;) displays a menu of options.
At the trip level you can add the home (CSU Oval) location or clear the list.
At the destination level you can remove that destination from the list.

#### Clicking on the URL in the footer should let me change the server.
Whenever a user clicks on the URL a popup should open showing the team name, the URL in an input text box, and a Cancel button.
When the user modifies the URL, the client will attempt to connect to the new server and update the configuration.
When the Test button is clicked, it will attempt to connect to the server.
If not successful, nothing changes and the user may continue to make URL changes or click the Cancel button to return to the original sever (it shouldn't change).
If successful, the new server name should appear and a Save button should replace the Test button.
When the user clicks the Save button, the server connection should change and the popup closes, revealing the new servername and URL in the footer.

### Component Hierarchy
The component hierarchy for the base application depicted below shows the our top level App component with four children components.
* App renders the major components on the screen.
* Header renders an icon and a team name in the top banner.
* Footer renders the current server connection in the bottom footer.
* Atlas renders a map.
* About renders information about the team.

![base component hierarchy](images/ComponentsBase.png)

We do not show the many ReactStrap components in this hierarchy, even though they will appear when you are debugging on the client.

### Class Diagram
The class diagram for the base application depicted below shows the basic structure of the web server application.

![class diagram](images/serverclasses.png )

The classes in blue represent the classes specific to this application.  
* WebApplication processes command line parameters and creates MicroServer.
* MicroServer start a web server on the given port, configures the server for security, static files, and APIs for different types of requests, and processes the requests as they arrive.
* JSONValidator verifies a request is properly formatted before attempting to process it using JSON Schemas.
* ConfigRequest is a specific request that allows the server to respond with its configuration to allow interoperability between clients and servers. 
* Request defines the basic components of all requests.
* BadReqeustException allows us to distinguish bad requests from other types of exceptions that may occur.

These test classes provide automated tests for unit testing.
* TestWebApplication
* TestConfigRequest
* TestJSONValidator


# Sprint 1


### User Interface

In this sprint, we will focus on team information.
There are two primary parts:
* browser tab, header, and footer.
* about page which includes team and member information,

Whenever a user clicks the team name in the header, a collapsible section should appear under the header with information about the team.
The collapsible map should disappear so only the about or map are displayed.
A simple toggle in state should be able to control this rendering.
The about page should contain the team name as a heading. 

![base](images/baseSprint1.jpg)

The team name in the browser tab, header and are simple changes to constants in the client and server.

### Client Components

We will add 3 new components to the base architecture on the client to support the about page.
* Team component will render the team information
* Person component will render the individual information for a team member
* AboutCard component will render the team/individual information in a consistent fashion.

The existing About component will be modified to control the layout of the Team and Person components on the page.

![components1](images/ComponentsSprint1.png)

### Server Classes
There are no changes to the server class structure in this sprint.
Only minor changes to text constants are required.

# Sprint 2

### User Interface

In this sprint, we will add some features to the server that will allow the user to interact with the interface and customize their experience. Users will now be able to search for locations in a search bar. As the user types, a drop-down menu will appear with matching locations. They can choose to click one of these, or simply search for a specific place without clicking a drop-down option.

![Add search bar](images/SearchBar.jpg)

The user will also now be able to change the server they are on by clicking the server link at the bottom of the web page. They can type in a new server link, test that the connection will work, and then switch connection to the new server. If the connection does not work, the user can return to the original server and continue as normal.

Lastly, the user can now set up location services. This will enable the website to track the user's current location. This allows the user to set their current location as the starting location.



### Client Components


By the end of this sprint, we will have a search bar component (SearchBar.js).
* Search bar component will allow the user to input what they would like to search

The existing search bar component will be modified to be able to take input and allow the user to make searches.

![components2](images/Sprint2Components.jpg)


### Server Classes

Files added:
FindRequest.java,
TestFindRequest.java

![class diagram](images/serverclassesdiagram2.png)


# Sprint 3

### User Interface
* added pop up alert
* User interface picture

### Client Components
By the end of this sprint, we will have the following componenets finished...
* A find places component where the user will be able to input a string in the search bar and a place/s will be listed.
* A where am I component where the user will be able to allow the website access so that their location can be determined, and their trip can start from the location that they are at.
* An interoperability component where our webisite is able to connect to other servers. This component will also warn the user if the URL is invalid. The component also informs the users what features are existing in each server.
* A distance component where the distance between places added to the trip will be calculated.

![component diagram](images/ComponentDiagramSprint3.jpg)

### Server Classes
* For sprint 3, we added: DistancesRequest.java. This file handles distance requests from the client.
* 
* Server class diagram

![class diagram](images/sprint3server.png)

# Sprint 4 

### User Interface

Currently, our Load Trip button is below the elipses in the bottom righthand corner of the UI. We plan to move that button into the dropdown menu. We additionally would like to add a Save Trip button which will allow the user to download a CSV or JSON file containing their current trip. 

We put the Load Trip, Save Trip, and Tour buttons in the dropdown menu, and changed the icons for Load and Save. Now, the buttons take up less space in our UI. When Load, Save, or Tour is clicked, a modal pops up that allows the user to utilize each feature. Tour is not fully implemented but still has a button and modal.

We altered the search bar so that the user can clear the search when they are done. Additionally, when the user searches for places, there is now a plus button on each place so the user can easily add each place to their trip. 

![UI Design](images/SP4design.jpg)

Additions to the UI include a Load Trip, Save Trip, and Shorter Trip button.

![Load Modal](images/LoadModalImage.png)

This is the modal that pops up when the user clicks the Load button.

![Save Modal](images/SaveModalImage.png)

This is the modal that pops up when the user clicks the Save button.

![Tour Modal](images/TourModalImage.png)

This is the modal that pops up when the user clicks the Tour button.



### Client Components
For sprint 4 we added new components such as a distance component taht allows the user to be able to know the distance between every place selected and the total distance within the distances. A Load component was also added to allow the user to load either a JSON or CSV file to the website and the webiste will populate the places in that were in the JSON or CSV file. A Save component was also added to allow the user to save their trip as either a JSON or CSV file. 

![component diagram](images/ComponentDiagramSprint4.jpg)


### Server Classes

For sprint 4 we added new files TourRequest.java and TestTourRequest.java for a new tour protocol. This new protocol will allow users to click a button to optimize their trip. We also added a corresponding test file for DistancesRequest.java which gives users information on the distances between locations on their trip.


![class diagram](images/sprint4serverdiagram2.png)


# Sprint 5

### User Interface
In sprint 5 we made several changes to the UI. We completed Trip Name, Maps, Save Map, Shorter Trip, Highlight Place, and Modify Trip. On top of this, we added cookie bars that pop up when certain actions are done.

First, we added Trip Name. Trip Name is labeled in the UI design image as number 2. When the user clicks the button that says "My Trip," a text box pops up that allows the user to input whatever name they want for their trip.

Then, marked in the image by number 1, we added the city, state (when applicable), and country to the search results. This was highly requested by our users and makes creating trips more intuitive. We also added a "show more" button next to each place in the trip, which reveals more information about each place if the user chooses to view it (demonstrated in the second image below).

We also added the Maps epic to our trip, marked by the first number 3. Upon clicking the button in the upper right-hand corner of the map, a dropdown appears which gives the user five choices for the format of their map. Marked by the second 3, we implemented Save Map; this feature lets the user download an image of the map with their trip on it. This functionality was added to the Save Modal, and the map can be downloaded as a .svg or a .kml file.

We also added Shorter Trip to our UI, which lets the user optimize their current trip to travel a shorter distance. Marked by number 4, this feature works by the user clicking the car button, choosing "optimize" in the pop-up modal, and then their trip will be rearranged into a shorter trip (with their starting point maintained). The shorter trip will appear on the map as well. Then a cookie bar will pop up in the lower left-hand corner of the screen, notifying the user that their trip has been optimized and that they can undo it if they please (demonstrated by the second cookie bar in the second image below). If they choose to undo their trip, they will see another cookie bar confirming that their original trip has been restored.

Next, we added Highlight Place. This makes it so that when a user clicks on a place in their trip, it is highlighted with a darker color. Lastly, our team completed Modify Trip. This epic has several components. First, in the UI there is a button with an up arrow and a down arrow to the left of the hotdog menu. When clicked, this button reverses the user's trip. Then, for each place in the trip, there is an up arrow and a down arrow; when clicked, these buttons move the place either up one spot or down one spot in their trip. The hotdog menu for each place additionally contains an option to move that place to the starting point.


![UI Design](images/sp5design.jpg)
Our UI, which demonstrates some of the buttons and modals we implemented.

![More UI features](images/sp5design2.jpg)
The new cookie bars our site uses and a look at the search feature.


### Client Components

For sprint 5 we have managed to complete everything that we planned in the beginning. We were able to successfully implement the client side of the tour/shorter trip component which now allows the user to optimize their trip and travel with less distance. After the user clicks optimize, the trip will be optimized, and a message will ask if the user wants to revert back to the original trip and undo any changes. Highlight trip was completed which now presents a cursor over the place that the user selects from the populated list below the map. After making a trip, the user is also allowed to save the actual map as either an SVG or KML file.

![component diagrammm](images/ComponentDiagramSprint5final.jpg)

### Server Classes

For sprint 5 we completed the shorter trip epic. This feature allows the user to select a shorter trip to the same destinations if one exists and then lets them choose the new trip. In the server, we completed the implementation of TourRequest.java to handle API requests from the client. We also completed the implementation of TourOptimizer.java. The tour optimizer class contains the `nearestNeighbor` function which handles most of the algorithm of the shorter trip feature.

![class diagram](images/sprint5serverdiagram2.png)
