# Sprint 4 - *T01* - *TRNG*

## Goal
### *Shorter tours!*

## Sprint Leader: 
### *Jonathan Guzman*

## Definition of Done

* The Increment release for `v4.x` created as a GitHub Release and deployed on black-bottle under SPRINT.
* The design document (`design.md`) is updated.
* The sprint document (`sprint.md`) is updated with scrums, completed metrics, review, and retrospective.

## Policies

### Mobile First Design
* Design for mobile, tablet, laptop, desktop in that order.
* Use ReactStrap for a consistent user experience (no HTML, CSS, style, etc.).

### Clean Code
* Code Climate maintainability of A (technical debt ratio==0).
* Minimize code smells and duplication.
* Use Single Responsibility Principle.

### Test Driven Development
* Write the tests before the code.
* Unit tests are fully automated.
* Code coverage is 70%

### Processes
* Incremental development.  No big bangs.
* Main is never broken. 
* All pull request builds and tests for Main are successful.
* All dependencies managed using Maven, npm, and WebPack.
* GitHub etiquette is followed always.


## Planned Epics

'Distances' is the first epic we plan on completing. Distances will give the distance between places in a trip. This will also include a cumulative trip distance at each place in their trip. The final location in the client's trip will calculate the distance from the final location to the starting point. This epic will also support the protocol of the distance feature on the client and server.

'Save Trip' is an epic in response to the client's request to have the ability to save their trip. This will allow the client to save their current trip in JSON and CSV formats. These formats will then allow the client to display their trip in a spreadsheet or a similar tool or, through future features, load it back into our application or others. The user will have the ability to choose the default format they prefer, which the system will remember for future sessions. The files will be saved in the local filesystem.

'Load Trip' is in further response to the client's requests in 'Save Trip,' users would also like the ability to load previously saved trips. The trips that were stored in their system will be able to be uploaded in the application. Similar to 'Save Trip,' the formats accepted include JSON and CSV.

'Shorter Trip' is a feature that will allow a user to see if a shorter trip exists between the destinations that were initially selected. Once the user selects the 'Shorter Trip' option, a newly rendered map will appear with a list of sorted destinations. Once this appears the user will have the ability to select the 'Shorter Trip' or keep their initially planned trip.

'User Experience' is an epic created from the user's request to improve their experience. TRNG will survey users to learn more about their experience using our application. All members of TRNG will be responsible to receive feedback from users with no previous experience with our application. We will then identify any changes that should be made to improve their experience in the future. Some areas of improvement may include but are not limited to: mobile user format responsiveness, minimal visual elements, progressive disclosure of information to the user, easy navigation, minimal scrolling, consistency with CSU web style guidelines, and meaningful icons and labels.


## Metrics

| Statistic | # Planned | # Completed |
| --- | ---: | ---: |
| Epics | *5* | *4* |
| Tasks |  *58*   | *91* | 
| Story Points |  *86*  | *114* | 


## Scrums

| Date | Tasks closed  | Tasks in progress | Impediments |
| :--- | :--- | :--- | :--- |
| *10/25* | *Sprint Planning, #368,#367,#371,#369* | *Assigning Tasks* | *Figuring out what are appropriate tasks for Shorter Trip, looks like this will be a hard epic* | 
| *10/27* | *#373,#178,#395,#398,#400,#391,#287* | *#267,#286,#288,#289,#311* | *Trying to get a window to pop up when either load or save trip icons are clicked* | 
| *10/29* | *#412,#411,#311,#409,#407,#380,#403,#183,#404,#379,#402,#378,#401,#399* | *#414,#413,#417,#415,#418,#420,#419,#416,#267* | *None at the moment* |
| *11/1* | *#416,#413,#414,#424,#423,#422,#425,#426,#427,#417,#420,#415,#418,#419* | *#267,#239,#237,#396,#389,#345,#245,#243* | *Having places in file show up on website* |
| *11/3* | *#428,#429,#185* | *#267,#239,#237,#396,#389,#345,#245,#243* | *None for now* |
| *11/4* | *#345,#352,#351,#350,#381,#288,#239,#237,#396,#389,#461,#286* | *#267,#289,#243,#245* | *having json be parsed and pop up on website* |
| *11/8* | *#289,#469,#470,#471,#468,#305,#306,#182,#475,#306* | *#267,#474,#245,#243,#475* | *None at the moment* |
| *11/10* | *#474,#243,#479,#478,#480,#355,#241,#236,#238,#485,#450,#484* | *#487,#447,#448,#482,#481,#267,#475,#245,#486,#488* | *None at the moment* |
| *11/11* | *#480,#355,#488,#502,#494,#501,#487,#509,#364,363,#365,#366,#362,#486,#482* | *None* | *CSV files are  not saving* |

## Review

### Epics completed
In this sprint, we completed 4 epics. Save Trip, Load Trip, Distances, and User Experience were completed.

Distances was the first epic that was completed. It was completed shortly after Sprint 4 began. This epic allowed clients to view the distance between places on their itinerary. Although our team struggled to complete this epic in Sprint 3, we were able to overcome our struggles with the formula and were able to successfully add the feature on the client and server-side.

Load Trip was the next epic that was completed. This epic was difficult due to the complexity involved in handling JSON and CSV input files on the server-side. We began this epic by doing validation handling. After the file was validated, depending on its format it was parsed and sent to a file converter. After the server-side was completed, we were able to load the trip into the itinerary for the user on the client-side.

Save Trip was completed shortly after Load Trip. We first completed the UI by adding a button and a pop-up modal. Save Trip was mainly difficult due to formatting the JSON and CSV files correctly.

User Experience was the final epic that our team completed. Our team was able to create a checklist for the user to go through to test our application successfully. This epic was not necessarily difficult but it did take time for each team member to ask a user to test our application.

### Epics not completed 
Shorter Trip was the only trip we were unable to complete. Our team was able to complete approximately a third of the epic. We were able to add a general UI component, which will allow us to have a good jump start for Sprint 5. Once we complete the server-side for Shorter Trip we will be able to connect the server-side with the finished client-side.

## Retrospective

### Things that went well
As a team, we did very good in comparison to the last two sprints that we have gone through. We got more done with much less conflicts along the way. We all continued to come to an agreement on when we are going to meet and have accomplished meeting regularly on a weekly basis. As a team, skills have vastly increased which has helped the team accomplish epics more efficiently. The team has continued to have faith in one another and prevent from falling apart. Having a member added to the team was a slight change in the beginning but we all managed to adapt quickly and thanks to this, everyone improved their skills and overall made the team stronger. 

### Things we need to improve
Having this sprint as one of the best sprints that the team has had, it is tough to say the areas that need improvement. We could improve on the team’s communication moving forward. This sprint there was not enough communication going on in the slack channel. Having a daily summary of tasks that we are working would be beneficial and help keep the team more organized. We could also improve on our workflow by being more organized with our Zen hub board. Moving epics/tasks in a more organized manner to our sprint backlog would help everyone know where the team is at in regard to tasks that still need to be completed.


### One thing we will change next time
Communicate on the slack channel on a daily basis about "daily task plan".
