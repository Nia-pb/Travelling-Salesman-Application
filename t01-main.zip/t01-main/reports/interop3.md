# Interop for t01

Interoperability testing allows us to verify correct operation when connected to another team's client or server.
Each team member must verify interoperability with the client and server from another team.
Each of the different aspects of the protocol must be verified.
We will discuss these issues with the other team and create defects in GitHub for any problems found in our system.
 
### Other Teams

This table lists each student in the team, the team they verified interoperability with, and the time to complete the testing.

| Name | Team | Time |
| ---- | ---- | ---- |
| Maya | 12 | 20 mins|
| Elita | 22 | 30 min |
| Nia | 16 | 30 min |
| Johnny | 3 | 25 min |
| Nik | 26 | 20 mins |


### Client Problems found

We found these problems when connecting our client to another team's server.

| team | problem | github# |
| :--- |  :--- | --- |
| 12 | The server connection pop-up box says "configfinddistances" instead of being separated by commas. | 262 |
| 26 | I am able to switch to team 26's server even though they have a feature (distances) that we don't have | 267 |
| 16 |  none found | --- |
| 03 | Nothing big other than not displaying features with commas in between | 262 |
| 22 |  none found | --- |



### Server Problems found

We found these problems when connecting the other team's client to our server.

| team |  problem | github# |
| :--- |  :--- | --- |
| 12 | Cannot connect to us because we don't have distances | 79 |
| 26 | No issues found | N/A |
| 16 | the search bar drop down only pulls up latitude and longitude, does not show places  | 265 |
| 03 | None Found | N/A|
| 22 | When searching to find a place, only the latitude and longitude are listed | 265 |
