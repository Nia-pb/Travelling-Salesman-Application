# Preferences for _Nia Bennabhaktula_

1. __Is it generally easier to reach you by text, electronic mail, voice mail or something else?  What hours?__ 
   * text or slack, available in the evenings usually after 3pm. If you cant reach me on slack and its urgent dont hesitate to call me. 
1. __What are your expectations about what your team will accomplish this semester?__ 
   * Expecting good communication and teamwork to be able to fiish tasks before the deadline. 
1. __What are your personal goals for improving your teamwork and communication skills this semester?__ 
   * Frequently checking the groupchat and communicating/offering help.
1. __What kinds of obstacles might you encounter in trying to reach both your team and personal goals?__ 
   * There might be someone whos unavailable and there timings are different. Im hoping we can figure this out
   * early in the semester and get used to everyones schedule. 
1. __What happens if some people on the team want to get an “A” while others think a “B” will be acceptable?__ 
   * We should talk about the issues and if cant resolve them we should have a meeting with Dave. 
1. __Is it acceptable for some team members to do more work on the assignment in order to get an “A”?__ 
   * No, I think we should all split the work as evenly as possible. 
1. __How much time per week do you anticipate it will take to make the project successful?__ 
   * 15-20 hours, possibly more.
1. __How will you decide who should do what on the project and activities?__ 
   * I think we should talk about our skillsets and see what project fits each teammate best. 
   * We should all help eachother out if someone is strugglig though. 
1. __What will happen if someone doesn’t follow through on a commitment (missing deadline, no show, etc.)?__ 
   * We should try to prevent this with communicating out deadlines in the first place, 
   * but if this does occur and we cant reach the person to figure out why then we should call a meeting with Dave.
1. __What happens if people have different opinions on the quality of the work?__ 
   * We should communicate these opinions and try to come to common grounds. 
1. __How will you deal with different work habits of team members?__ 
   * I will try to compromise things on my part if it helps the team - and if its something
   * that i cant, i'll communicate that with my team and hope to meet in the middle. 
1. __Do you want to have a standing meeting time outside of class?__ 
   * Yes, but if my teammates have busy schedules, we should talk about what times for a meeting works with 
   * everyone at the begining of each week and meet accordingly. 
1. __How often do you think the team will need to meet outside of class?__ 
   * 2-3 times a week.
1. __Will you need approval of every team member before making a decision?__ 
   * If its a decision that effects everyone then yes, if its a smaller thing then I dont think so. 
1. __What will you do if every team member except one agrees on something?__ 
   * Try to understand why they are disagreeing and see if we can adjust the plans. 
1. __What will you do if one person seems to be dominating the team process?__ 
   * Communicate with them.
1. __What will you do if you feel most of the facilitation responsibilities are falling on you?__ 
   * Again, i will try to talk with my team first and see if we can resolve this,
   * but if we arent able to i would suggest a team meeting with Dave. 
