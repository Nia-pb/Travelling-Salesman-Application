# Preferences for Nik Torraca

1. __Is it generally easier to reach you by text, electronic mail, voice mail or something else?  What hours?__ 
   * Text is the easiest way to get ahold of me. Slack/discord will work fine when I am on my computer. I work until around 4, so you should be able to reach me any time after that (and anyone on the weekends). 
1. __What are your expectations about what your team will accomplish this semester?__ 
   * I expect our team will develop a consistent and effective way of communicating so we can complete our projects on time. 
1. __What are your personal goals for improving your teamwork and communication skills this semester?__ 
   * Since I am taking this class online, my goal is to do everything I can to stay involved with the team and communicate as much as I can. 
1. __What kinds of obstacles might you encounter in trying to reach both your team and personal goals?__ 
   * I have a very busy schedule this semester, working full time and taking 3 classes, so time management/finding the energy to do all my work will be one of my biggest obstacles. 
   * Also, communicating with the team since I won’t be able to work in person with everyone. 
1. __What happens if some people on the team want to get an “A” while others think a “B” will be acceptable?__ 
   * I think we shouldn’t settle, and we should work hard to get the best grade we can get. That way, whatever grade that is, we can all be satisfied that we tried our best. 
1. __Is it acceptable for some team members to do more work on the assignment in order to get an “A”?__ 
   * Although it’s might not possible for everyone to do the same exact amount of work, we should do our best do divide up the work evenly.
1. __How much time per week do you anticipate it will take to make the project successful?__ 
   * My guess is around 15 hours.  
1. __How will you decide who should do what on the project and activities?__ 
   * Set up a meeting to discuss and talk about our strengths and weaknesses/what we would like to work on.
1. __What will happen if someone doesn’t follow through on a commitment (missing deadline, no show, etc.)?__ 
   * Communicate with this person, and express to them that they need to follow through on commitments. If this is a recurring problem, we will make note of this on our evaluations of our teammates. 
1. __What happens if people have different opinions on the quality of the work?__ 
   * Communicate these opinions with each other and try to find some common ground. If someone is satisfied with very poor quality, we might need to talk to them and let them know that is not acceptable on a group project.  
1. __How will you deal with different work habits of team members?__ 
   * People will have different work habits, and that is OK. As long as people aren’t trying to finish the entire project fight before it is due. If that is the case, we need to work with that person to find a better schedule to work on the project. 
1. __Do you want to have a standing meeting time outside of class?__ 
   * I won’t be able to meet in person, I am taking this class online. I could do zoom/teams meetings though. 
1. __How often do you think the team will need to meet outside of class?__ 
   * If we are doing online meetings, maybe a couple times a week. 
1. __Will you need approval of every team member before making a decision?__ 
   * If it is a decision that will affect the project everyone is working on, I would give everyone an opportunity to give their opinion. 
1. __What will you do if every team member except one agrees on something?__ 
   * Try to get that person on board or make a small compromise. If that person refuses to compromise, they might need to be overruled. 
1. __What will you do if one person seems to be dominating the team process?__ 
   * Talk to that person with the team and communicate any potential issues.  
1. __What will you do if you feel most of the facilitation responsibilities are falling on you?__ 
   * If I felt too much of the facilitation responsibilities were falling on me, I will communicate that with the team and ask them to help a little more with that responsibility. 
