# Preferences for Elita Danilyuk

1. __Is it generally easier to reach you by text, electronic mail, voice mail or something else?  What hours?__ 
   * The easiest for me is via text and/or phone call. Slack and Teams work well if you @ me.
   * Generally I'm available after 3:00 with some class exceptions. I am good about taking care of urgent matters.
1. __What are your expectations about what your team will accomplish this semester?__ 
   * I expect that our team will communicate well and not only finish tasks on time but excel at our projects!
1. __What are your personal goals for improving your teamwork and communication skills this semester?__ 
   * My personal goals are to be available to my teammates and help wherever I can.
1. __What kinds of obstacles might you encounter in trying to reach both your team and personal goals?__ 
   * I'm worried about my work and school schedules. Also, I hope I don't get in the way of myself with stress and worry.
1. __What happens if some people on the team want to get an “A” while others think a “B” will be acceptable?__ 
   * We should be vocal and open with one another and discuss our goals. If we are not able to resolve this ourselves, we should reach out to Dave.
1. __Is it acceptable for some team members to do more work on the assignment in order to get an “A”?__ 
   * No, I think we should work together as a team and put in an equal amount of effort.
1. __How much time per week do you anticipate it will take to make the project successful?__ 
   * I'm genuinely not sure, I would say anywhere around 14-20 hours.
1. __How will you decide who should do what on the project and activities?__ 
   * The team should have open and honest discussions about who is comfortable doing which tasks. We should optimize tasks based off strengths and weaknesses.
1. __What will happen if someone doesn’t follow through on a commitment (missing deadline, no show, etc.)?__ 
   * We should have clear communication to avoid this, but we would need to speak to the individual and try to understand why it was missed or why they no-showed. If it happened because of negligence then we need to discuss it with Dave.
1. __What happens if people have different opinions on the quality of the work?__ 
   * Again, we need to communicate and be open-minded with one another. If people have a 'higher-quality' it may be a good goal to reach for as a team. Sometimes we need to learn from one another, other times people need to understand that not everyone is at the 'same level'.
1. __How will you deal with different work habits of team members?__ 
   * I will try to understand and see the pattern of their habits. If it's a healthy habit, I'm happy to compromise and will understand. Otherwise, I will communicate openly and honestly and go from there.
1. __Do you want to have a standing meeting time outside of class?__ 
   * Yes, I think it would be extremely helpful for the team.
1. __How often do you think the team will need to meet outside of class?__ 
   * I would say about 1-4 times a week, depending on the intensity of the project/workload that week.
1. __Will you need approval of every team member before making a decision?__ 
   * I think it depends on the impact of the decision. If it's a large decision we should try to, but if there's a time constraint then I think the person who is unreachable should understand.
1. __What will you do if every team member except one agrees on something?__ 
   * I would try to see why they disagree with an open mind and go from there. If it's unreasonable then they should be willing to compromise.
1. __What will you do if one person seems to be dominating the team process?__ 
   * Honestly communicate and talk with them.
1. __What will you do if you feel most of the facilitation responsibilities are falling on you?__ 
   * Again, I would honestly communicate with my team members and try to delegate tasks.
