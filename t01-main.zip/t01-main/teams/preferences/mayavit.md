# Preferences for Maya Vitrano

1. __Is it generally easier to reach you by text, electronic mail, voice mail or something else?  What hours?__ 
   *    You can reach me by any of these, but I will respond fastest to text! I'll probably respond throughout the day, but I
         am usually free in the morning from 8am to 11am, and then in the evening from 5pm-11pm.
1. __What are your expectations about what your team will accomplish this semester?__ 
   *    I expect that this team will feel comfortable enough with each other to be transparent.
          I also think this team will develop a good dynamic where we can efficiently and frictionlessly 
          work on tasks.
1. __What are your personal goals for improving your teamwork and communication skills this semester?__ 
   *    I would like to become better at not being super particular about the way things are done. 
1. __What kinds of obstacles might you encounter in trying to reach both your team and personal goals?__ 
   *    I could potentially come across as rude if I have a different idea about how to do something as someone else, so I 
        just want to make sure everyone feels comfortable disagreeing. 
1. __What happens if some people on the team want to get an “A” while others think a “B” will be acceptable?__ 
   *    We would have to have a meeting where we talk about our expectations and what we are willing to do to meet everyone's expectations.
1. __Is it acceptable for some team members to do more work on the assignment in order to get an “A”?__ 
   *    No
1. __How much time per week do you anticipate it will take to make the project successful?__ 
   *    10 - 20 hours, depending on what needs to be done each week.
1. __How will you decide who should do what on the project and activities?__ 
   *    We should decide this based on everyone's individual area of expertise, as well as what people would prefer to do.
1. __What will happen if someone doesn’t follow through on a commitment (missing deadline, no show, etc.)?__ 
   *    We should confront them or meet with Dave.
1. __What happens if people have different opinions on the quality of the work?__ 
   *    We would need to have a really honest meeting with each other to decide on how we want things done. 
1. __How will you deal with different work habits of team members?__ 
   *    Good communication. As long as you know each person will do what they need to do in time, it shouldn't be a problem. 
        If we communicate our work habits well, hopefully nobody will be anxiously waiting for someone to complete something.
1. __Do you want to have a standing meeting time outside of class?__ 
   *    This could be helpful, but I am flexible.
1. __How often do you think the team will need to meet outside of class?__ 
   *    One to three times a week. More, if everyone is avaliable.
1. __Will you need approval of every team member before making a decision?__ 
   *    This would be ideal, but might not work for *every* decision. In these cases, I hope for at least a majority to be in agreement.
1. __What will you do if every team member except one agrees on something?__ 
   *    I'd like to communicate with them to see if we can figure something out. If we are at a total standstill, maybe having a meeting with Dave would be helpful.
         I do think everyone's voice is important and should have a say.
1. __What will you do if one person seems to be dominating the team process?__ 
   *    See if my other teammates feel the same way and then have a meeting together to kindly discuss the issue
1. __What will you do if you feel most of the facilitation responsibilities are falling on you?__ 
   *    I would try to openly communicate this to my teammates. 
