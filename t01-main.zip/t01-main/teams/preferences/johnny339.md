# Preferences for Johnny Guzman

1. __Is it generally easier to reach you by text, electronic mail, voice mail or something else?  What hours?__ 
   * Text would be the easiest for me as I can do a quick reply and will most likely always see it. As far as hours go, I am free to respond any time of the day, if you want to meet up it would have to be after 4pm.
1. __What are your expectations about what your team will accomplish this semester?__ 
   * I expect that we all learn as a team and help each other out. Have everyone communicate properly and overall have fun with this project.
1. __What are your personal goals for improving your teamwork and communication skills this semester?__ 
   * My goals are to frequently check slack, or any other group chats we have, quickly address a problem that I am having to the group so that it doesn't affect anything else.
1. __What kinds of obstacles might you encounter in trying to reach both your team and personal goals?__ 
   * Trying to know everyone’s availability and when it will be possible to meet when needed
   * Getting caught up with other things that I totally forget to check slack or any other chat 
   * Forget to communicate the important stuff towards the beginning
1. __What happens if some people on the team want to get an “A” while others think a “B” will be acceptable?__ 
   * When others want to strive for what’s enough and others want more than enough, this is where the main conflict begins. There should first be a group meeting to come to a consensus. If there is still a problem, then a meeting with the professor must be made (aka our boss).
1. __Is it acceptable for some team members to do more work on the assignment in order to get an “A”?__ 
   * I believe that this is not acceptable, everyone should be doing equal amounts of work. If that person is struggling, if it is in my hands to be able to help, I will.
1. __How much time per week do you anticipate it will take to make the project successful?__ 
   * I would say it would take like a typical part time job, 10-20 hours per week.
1. __How will you decide who should do what on the project and activities?__ 
   * Based on their strengths
   * Anyone who wants more practice with a specific part
   * Everyone should still be able to help everyone. 
1. __What will happen if someone doesn’t follow through on a commitment (missing deadline, no show, etc.)?__ 
   * Find a way to make up for it, double up on an assignment or some sort of way to show that there is still interest and willing to work with the group. 
   * First, a meeting with the teammates should be made so that an agreement could be made
   * If no agreement was made, set up a meeting with the Dave
1. __What happens if people have different opinions on the quality of the work?__ 
   * Everyone should be open to observing different opinions
   * If a team member is probably going overboard with what is quality and the rest disagree, that must be addressed
   * At the end of the day, an agreement should be made. 
1. __How will you deal with different work habits of team members?__ 
   * I will try to find as many similar habits as I can with my team members so that we can use that as an advantage to stay on top of this project
   * If not, I will communicate my habits and talk with my teammates to come to a consensus
   * If it is needed to change some habits to help us be successful, I would be willing to change or add some habits
1. __Do you want to have a standing meeting time outside of class?__ 
   * I would prefer that since it will make me commit more time into working on this project
   * doesn’t have to be every day, if it can be a schedule where everyone’s progress can be checked, and constant help is available
1. __How often do you think the team will need to meet outside of class?__ 
   * Once a week at minimum if everyone else has a busy schedule
   * I would like 3 times a week so that it prevents from pushing this project to the side while we get caught up with other classes
1. __Will you need approval of every team member before making a decision?__ 
   * I would like this; this would let me know if I am doing it right and a good job as well
1. __What will you do if every team member except one agrees on something?__ 
   * I will personally talk with that team member and try to see if we both understand each other and come to a consensus
1. __What will you do if one person seems to be dominating the team process?__ 
   * If it benefits the team, I’m going to let that person do their thing
   * If it seems to be digging a hole for the team, I will call them out and have a group meeting to do some changes before it gets worse
1. __What will you do if you feel most of the facilitation responsibilities are falling on you?__ 
   * I will communicate with my teammates and let them know what is going on 
   * Overall, I really hope that our team does not get to the point of having to meet with Dave
