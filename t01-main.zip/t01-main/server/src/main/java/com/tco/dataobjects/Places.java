package com.tco.dataobjects;

import java.util.ArrayList;

public class Places extends ArrayList<Place> {

    public int size;
    public int found;
}