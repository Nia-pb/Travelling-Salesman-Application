package com.tco.requests;

import com.tco.dataobjects.Place;
import com.tco.dataobjects.Places;
import com.tco.database.PlaceDataAccessor;
import com.tco.misc.TourOptimizer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TourRequest extends Request {
    private final transient Logger log = LoggerFactory.getLogger(TourRequest.class);
        
    public long earthRadius;
    public int response;
    public Places places; 
    public Places tour;

    @Override
    public void buildResponse() {
        places = this.places;
        places = getNearestNeighbor();
        log.trace("buildResponse -> {}", this);
    }

    public Places getNearestNeighbor(){
        if (places.size() > 1) {   
            Places tourPlaces = new Places();
            int[] result = TourOptimizer.tourOptimizer(places, earthRadius, response);
            for (int i = 0; i < result.length; i++) {
                tourPlaces.add(places.get(result[i]));
            }
            return tourPlaces;
        }
        return places;
    }

  /* The following methods exist only for testing purposes and are not used
  during normal execution, including the constructor. */

    public TourRequest() {
        this.requestType = "tour";
    }
}
