package com.tco.database;

import com.tco.server.WebApplication;
import com.tco.dataobjects.Place;
import com.tco.dataobjects.Places;

import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.PreparedStatement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PlaceDataAccessor {

    private final static Logger log = LoggerFactory.getLogger(Logger.class);
    private final static String BASE_QUERY = "FROM " + Database.WORLD_TABLE
        + " INNER JOIN country ON world.iso_country = country.id"
        + " INNER JOIN region ON world.iso_region = region.id"
        + " INNER JOIN continent ON world.continent = continent.id"
        + " WHERE world.name LIKE ? OR municipality LIKE ? OR region.name LIKE ? OR world.id LIKE ? OR continent.name LIKE ?";

    private final static int NUM_QUERY_VARS = 5;

    public static Places getPlaces(String match) {
        return getPlaces(match, 0);
    }

    public static Places getPlaces(String match, int limit) {
        Places places = new Places();
        int found = 0;

        try {
            found = getFound(match);

            if (found > 0) {
                ResultSet result = queryPlaces(match, limit);
                places = resultsToObjects(result);
                result.close();
            }
        } catch (SQLException e) {
            log.error("Server encountered a SQL error when running getPlaces: {}", e.getMessage());
        }

        places.found = found;

        return places;
    }

    public static int getFound(String match) throws SQLException {
        PreparedStatement query = WebApplication.database.prepareStatement("SELECT COUNT(*) " + BASE_QUERY);
            
        String likeExpr = "%" + match + "%";
        for (int i = 1; i <= NUM_QUERY_VARS; i++) {
            query.setString(i, likeExpr);
        }

        ResultSet result = query.executeQuery();

        result.next();
        int found = result.getInt(1);

        result.close();

        return found;
    }

    public static ResultSet queryPlaces(String match, int limit) throws SQLException {
        String sql = "SELECT * " + BASE_QUERY;

        if (limit != 0) {
            sql += " LIMIT ?";
        }

        PreparedStatement query = WebApplication.database.prepareStatement(sql);
        
        String likeExpr = "%" + match + "%";
        for (int i = 1; i <= NUM_QUERY_VARS; i++) {
            query.setString(i, likeExpr);
        }

        if (limit != 0) {
            query.setInt(NUM_QUERY_VARS + 1, limit);
        }

        return query.executeQuery();
    }

    public static Places resultsToObjects(ResultSet result) throws SQLException {
        Places places = new Places();
        int size = 0;
        while (result.next()) {
            Place place = new Place(result.getInt("index"), result.getString("world.id"), result.getString("type"), result.getString("world.name"), 
                                    result.getString("latitude"), result.getString("longitude"), result.getString("altitude"), result.getString("world.continent"),
                                    result.getString("iso_country"), result.getString("iso_region"), result.getString("municipality"), 
                                    result.getString("scheduled_service"), result.getString("gps_code"), result.getString("iata_code"), 
                                    result.getString("local_code"), result.getString("home_link"), result.getString("wikipedia_link"),
                                    result.getString("world.keywords"), result.getString("country.name"), result.getString("region.name"));
            places.add(place);
            size++;
        }
        places.size = size;
        return places;
    }
}
