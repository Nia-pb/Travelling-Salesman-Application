package com.tco.requests;

import java.util.ArrayList;
import com.tco.dataobjects.Place;
import com.tco.dataobjects.Places;
import com.tco.database.PlaceDataAccessor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FindRequest extends Request {
    
    public final static int SERVER_RESULT_LIMIT = 1000; // 0 for unlimited
    public final static String RANDOM_MATCH = ""; // If the match property is "", get random results

    private final transient Logger log = LoggerFactory.getLogger(FindRequest.class);
        
    public String match;
    public int limit;
    public int found;
    public Places places;

    @Override
    public void buildResponse() {
        int useLimit = limit;

        if (!limitInBounds(limit)) {
            useLimit = SERVER_RESULT_LIMIT;
        }

        places = PlaceDataAccessor.getPlaces(match, useLimit);
        found = places.found;

        log.trace("buildResponse -> {}", this);
    }

    public boolean limitInBounds(int limit) {
        if (limit == 0 && SERVER_RESULT_LIMIT != 0) {
            return false;
        }

        if (limit <= SERVER_RESULT_LIMIT) {
            return true;
        }

        return false;
    }

  /* The following methods exist only for testing purposes and are not used
  during normal execution, including the constructor. */

    public FindRequest() {
        this.requestType = "find";
    }
}
