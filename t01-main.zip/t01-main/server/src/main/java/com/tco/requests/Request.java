package com.tco.requests;
import java.util.ArrayList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import com.tco.misc.BadRequestException;

public abstract class Request {
    
    public String requestType;

    public String getRequestType() {
        return requestType;
    }
    
    // Overrideable Methods
    public abstract void buildResponse() throws BadRequestException;
}
