package com.tco.misc;

import java.lang.Object;
import java.util.Arrays;
import com.tco.dataobjects.Place;
import com.tco.dataobjects.Places;
import com.tco.database.PlaceDataAccessor;
import com.tco.requests.DistancesRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TourOptimizer {

    public static int[] tourOptimizer(Places places, double earthRadius, int response){
        double[][] distanceMatrix = makeDistanceMatrix(places, earthRadius);
        int[] shortestTour = nearestNeighbor(places, distanceMatrix, response);
        int[] rotatedTour = rotateTour(shortestTour);
        return rotatedTour;
    }

    public static double[][] makeDistanceMatrix(Places places, double earthRadius) {
        double[][] distanceMatrix = new double[places.size()][places.size()];
        for (int i = 0; i < places.size()-1; i++) {
            for (int j = i+1; j < places.size(); j++) {
                distanceMatrix[i][j] = computeDist(places.get(i), places.get(j), earthRadius);
            } 
        }

        // Fills lower half of distance matrix: 
        for (int i = 0; i < distanceMatrix[0].length; i++) {
            for (int j = 0; j < distanceMatrix[0].length; j++) {
                if (i != j && distanceMatrix[j][i] == 0.0) {
                    distanceMatrix[j][i] = distanceMatrix[i][j];
                }
            }
        }

        return distanceMatrix;
    }

    public static double computeDist(Place place1, Place place2, double earthRadius) {
        DistancesRequest distReq = new DistancesRequest();
        return distReq.greatCircleDistance(place1.getLat(), place1.getLng(), place2.getLat(), place2.getLng(), earthRadius);
    }


    public static int[] nearestNeighbor(Places places, double[][] distanceMatrix, int response) {
        int[] shortestTour = populateShortestTour(places); int[] currentTour = new int[places.size()];
        boolean[] visited = new boolean[places.size()]; long startTime = System.currentTimeMillis();
        double shortestDistSum = Double.POSITIVE_INFINITY; double currentDistSum;
        int indexOfNextStop = 0; int indexOfCurrentStop = 0; int index;

        for (int i = 0; i < places.size(); i++) {
            if (System.currentTimeMillis() - startTime > (response*1000)*.6)
                {  break; }
            Arrays.fill(currentTour, -1); Arrays.fill(visited, false);
            currentTour[0] = i; currentDistSum = 0;
            index = 1; visited[i] = true;
            
            while (containsFalse(visited) && index < places.size()) {
                double minDist = Double.POSITIVE_INFINITY;

                    for (int x = 0; x < visited.length; x++) {
                        if(!visited[x]) {
                            if(distanceMatrix[indexOfCurrentStop][x] < minDist && indexOfCurrentStop != x) {
                                minDist = distanceMatrix[indexOfCurrentStop][x]; 
                                indexOfNextStop = x; } } }

                    currentTour[index] = indexOfNextStop; index++;
                    visited[indexOfNextStop] = true;
                    currentDistSum += minDist;
                    indexOfCurrentStop = indexOfNextStop; indexOfNextStop = 0; }

            if(currentDistSum < shortestDistSum) {
                shortestTour = Arrays.copyOf(currentTour, shortestTour.length);
                shortestDistSum = currentDistSum; } }
        
        return shortestTour;
    }


    public static int[] populateShortestTour(Places places) {
        int[] result = new int[places.size()];
        for(int i = 0; i < places.size(); i++) {
            result[i] = i;
        }
        return result;
    }

    public static boolean containsFalse(boolean[] visited) {
        for(int i = 0; i < visited.length; i++) {
            if(!visited[i]) {
                return true;
            }
        }
        return false;
    }

    public static int[] rotateTour(int[] shortestTour) {
        int startInd = getZeroInd(shortestTour);
        int[] result1 = Arrays.copyOfRange(shortestTour, startInd, shortestTour.length);
        int[] result2 = Arrays.copyOfRange(shortestTour, 0, startInd);
        int[] result = new int[shortestTour.length];
        System.arraycopy(result1, 0, result, 0, result1.length);
        System.arraycopy(result2, 0, result, result1.length, result2.length);
        return result;
    }

    public static int getZeroInd(int[] shortestTour) {
        for (int i = 0; i < shortestTour.length; i++) {
            if (shortestTour[i] == 0) {
                return i;
            }
        }
        return -1;
    }

}