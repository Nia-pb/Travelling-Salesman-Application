package com.tco.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Database {

    // Database table names for core database
    public final static String WORLD_TABLE = "world";
    public final static String CONTINENT_TABLE = "continent";
    public final static String COUNTRY_TABLE = "country";
    public final static String REGION_TABLE = "region";

    protected final static int TIMEOUT_TIME_S = 6; // Time in seconds of how long to wait for a connection to reply before making a new connection.

    public Connection connection;
    public enum State {CONNECTION_FAILED, CONNECTED, DISCONNECTED};
    private State state;
    private DatabaseCredential credential;

    private final static Logger log = LoggerFactory.getLogger(Database.class);

    public Database(DatabaseCredential credential) {
        this.credential = credential;

        try {
            connect();
            setState(State.CONNECTED);
        } catch (SQLException e) {
            setState(State.CONNECTION_FAILED);
            log.error("Server encountered a SQL error when connecting: {}", e.getMessage());
        }
    }
    
    public State getState() {
        return state;
    }

    private void setState(State state) {
        this.state = state;
    }

    private void connect() throws SQLException {
        if (!isConnected()) {
            connection = DriverManager.getConnection(credential.getConnectionStr(), credential.username, credential.password);
        }
    }

    public boolean isConnected() {
        boolean isConnected = false;

        try {
            if (connection != null && isOpen() && connection.isValid(TIMEOUT_TIME_S)) {
                isConnected = true;
            }
        } catch (SQLException e) {
            log.error("Server encountered a SQL error when checking isConnected: {}", e.getMessage());
        }

        return isConnected;
    }
    
    public boolean isOpen() {
        boolean isOpen = false;

        try {
            if (connection != null && !connection.isClosed()) {
                isOpen = true;
            }
        } catch (SQLException e) {
            log.error("Server encountered a SQL error when checking isOpen: {}", e.getMessage());
        }

        return isOpen;
    }

    public void disconnect() {
        if (isOpen()) {
            try {
                connection.close();
                setState(State.DISCONNECTED);
            } catch (SQLException e) {
                log.error("Server encountered a SQL error when disconnecting: {}", e.getMessage());
            }
        }
    }

    public void wakeup() {
        try {
            connect();
            if (getState() != State.CONNECTED) {
                setState(State.CONNECTED);
                log.info("Database connection has woken up or restored for a query {}@{}", credential.username, credential.connectionUrl);
            }
        } catch (SQLException e) {
            setState(State.CONNECTION_FAILED);
            log.error("Server database connection was lost when attempting to connect to the database. SQL error: {}", e.getMessage());
        }
    }

    /* Database query method and overloads */

    public ResultSet query(String sql) throws DatabaseQueryException {
        wakeup();

        if (getState() == State.CONNECTION_FAILED || getState() == State.DISCONNECTED) {
            throw new DatabaseQueryException();
        }
    
        ResultSet results;

        try {
            Statement query = connection.createStatement();
            results = query.executeQuery(sql);
        } catch (SQLException e) {
            log.error("Server database query failed. SQL error: {}", e.getMessage());
            throw new DatabaseQueryException();
        }

        return results;
    }

     /* Provide a wrapper, keep-alive interface for the outside world */

     public PreparedStatement prepareStatement(String sql) throws SQLException {
        wakeup();

        PreparedStatement query = connection.prepareStatement(sql);

        return query;
     }
}