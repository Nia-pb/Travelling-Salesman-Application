package com.tco.dataobjects;

public class Place {
    public static transient String BASE_URL = "https://www.aopa.org/destinations/airports/";
    public static transient String EXTRA_URL = "/details";


    // Map columns from the database to the data object
    public transient int index;
    public transient String id;
    public String name;
    public String latitude;
    public String longitude;
    public String altitude;
    public String type;
    public String country;
    public String region;
    public String municipality;
    public String url; // Set from gps_code
    public transient String continent;
    public transient String iso_country;
    public transient String iso_region;
    public transient String scheduled_service;
    public transient String gps_code;
    public transient String iata_code;
    public transient String local_code;
    public transient String home_link;
    public transient String wikipedia_link;
    public transient String keywords;

    public Place(int index,
                String id,
                String type,
                String name,
                String latitude,
                String longitude,
                String altitude,
                String continent,
                String iso_country,
                String iso_region,
                String municipality,
                String scheduled_service,
                String gps_code,
                String iata_code,
                String local_code,
                String home_link,
                String wikipedia_link,
                String keywords,
                String country,
                String region) {
        this.index = index;
        this.id = id;
        this.type = type;
        this.name = name;
        this.latitude = latitude;
        this.longitude = longitude;
        this.altitude = altitude;
        this.continent = continent;
        this.iso_country = iso_country;
        this.iso_region = iso_region;
        this.municipality = municipality;
        this.scheduled_service = scheduled_service;
        this.gps_code = gps_code;
        this.iata_code = iata_code;
        this.local_code = local_code;
        this.home_link = home_link;
        this.wikipedia_link = wikipedia_link;
        this.keywords = keywords;
        this.country = country;
        this.region = region;

        // Handle URL
        this.url = BASE_URL + gps_code + EXTRA_URL;
    }

    public Place(String name, String latitude, String longitude) {
        this.name = name;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public Place(String latitude, String longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public double getLat() {
        return Double.parseDouble(latitude);
    }

    public double getLng() {
        return Double.parseDouble(longitude);
    }

    // public String toString() {
    //     return this.name + ", " + this.get
    // }
}