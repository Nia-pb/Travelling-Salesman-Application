package com.tco.database;

public class DatabaseQueryException extends Exception {}