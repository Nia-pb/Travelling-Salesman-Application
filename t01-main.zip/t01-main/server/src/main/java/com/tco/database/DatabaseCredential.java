package com.tco.database;

public class DatabaseCredential {
    public String username;
    public String password;
    public String connectionUrl;
    public String connectionProperties;

    public DatabaseCredential(String username, String password, String connectionUrl, String connectionProperties) {
        this.username = username;
        this.password = password;
        this.connectionUrl = connectionUrl;
        this.connectionProperties = connectionProperties;
    }

    public DatabaseCredential(String username, String password, String connectionUrl) {
        this(username, password, connectionUrl, "");
    }

    public String getConnectionStr() {
        String connectionStr;

        if (connectionProperties == null || connectionProperties.equals("")) {
            connectionStr = connectionUrl;
        } else {
            connectionStr = connectionUrl + "?" + connectionProperties;
        }

        return connectionStr;
    }
}