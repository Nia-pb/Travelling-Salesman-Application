package com.tco.requests;

import java.util.ArrayList;
import java.util.HashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.everit.json.schema.SchemaException;
import org.everit.json.schema.Schema;
import org.everit.json.schema.loader.SchemaLoader;
import org.everit.json.schema.ValidationException;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import com.google.gson.Gson; 
import com.google.gson.GsonBuilder;

import com.tco.dataobjects.Places;
import com.tco.dataobjects.Place;

public class DistancesRequest extends Request { 

    public double earthRadius;
    public Places places;
    private final transient Logger log = LoggerFactory.getLogger(ConfigRequest.class);
    public ArrayList<Long> distances;
    public String name;
    

    @Override
    public void buildResponse() {
        distances = new ArrayList<Long>();
        earthRadius = getEarthRadius();
        places = this.places;
        distances = getDistances();
        log.trace("buildResponse -> {}", this);
    }

     private ArrayList<Long> getDistances(){
        long singleDistance;
        double lat1 = 0;
        double lat2 = 0;
        double lon1 = 0;
        double lon2 = 0;

        
        if(places.size() > 0 ){
            lat1 = Double.parseDouble(places.get(0).latitude);
            lon1 = Double.parseDouble(places.get(0).longitude);
        }

        if (places.size() == 1) {
            distances.add(0L);
        }

        for(Integer i = 1 ; i<places.size(); i++){

            lat1 = Double.parseDouble(places.get(i-1).latitude);
            lon1 = Double.parseDouble(places.get(i-1).longitude);
            lat2 = Double.parseDouble(places.get(i).latitude);
            lon2 = Double.parseDouble(places.get(i).longitude);

            singleDistance = greatCircleDistance(lat1, lon1, lat2, lon2, earthRadius);

            distances.add(singleDistance);
        }
        if(places.size() > 1){
            singleDistance = greatCircleDistance(lat2, lon2, Double.parseDouble(places.get(0).latitude), Double.parseDouble(places.get(0).longitude), earthRadius);
            distances.add(singleDistance);
        }

        return distances;
   }

    public long greatCircleDistance(double lat1, double lon1, double lat2, double lon2, double earthRadius){
        
        double centralAngle;
        double finDist;
    
        lat1 = Math.toRadians(lat1); //31.92180801
        lat2 = Math.toRadians(lat2); //-27.191944122314453
        lon1 = Math.toRadians(lon1);  //48.87751713
        lon2 = Math.toRadians(lon2); 

        double num =  Math.sqrt( ( Math.pow( (Math.cos(lat2) * (Math.sin(Math.abs(lon1 - lon2)))), 2) ) +
        (Math.pow( (Math.cos(lat1) * Math.sin(lat2)) - (Math.sin(lat1) * Math.cos(lat2) * Math.cos(Math.abs(lon1 - lon2))),2 ) ) );

        double den = ( (Math.sin(lat1) * Math.sin(lat2)) + (Math.cos(lat1) * Math.cos(lat2) * Math.cos(Math.abs(lon1 - lon2))));

        centralAngle = Math.atan2(num, den); 

        finDist = Math.abs(centralAngle * earthRadius);

        return Math.round(finDist);
    }
    
    public DistancesRequest() {
        this.requestType = "distances";
    }

    public double getEarthRadius() {
        return this.earthRadius;
    }

}