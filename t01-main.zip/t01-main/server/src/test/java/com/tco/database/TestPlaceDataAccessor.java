package com.tco.database;

import com.tco.dataobjects.Places;
import com.tco.server.WebApplication;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;

public class TestPlaceDataAccessor {
    @BeforeEach
    public void setupForDataAccessor() {
        if (WebApplication.database == null) {
            String port = "31400";
            String[] commandLineArguments = {port};
            WebApplication.main(commandLineArguments);
        }
    }

    @Test
    @DisplayName("PlaceDataAccessor runs getPlaces")
    public void testGetPlaces() {
        Places places = PlaceDataAccessor.getPlaces("test", 10);
    }

    @Test
    @DisplayName("PlaceDataAccessor runs getPlaces with a limit of 0")
    public void testGetPlacesNoLimit() {
        Places places = PlaceDataAccessor.getPlaces("test");
    }
}