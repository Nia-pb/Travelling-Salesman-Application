package com.tco.requests;

import com.tco.dataobjects.Places;
import com.tco.dataobjects.Place;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class TestDistancesRequest {

    private DistancesRequest distances;

    @BeforeEach
    public void createDistances() {
        distances = new DistancesRequest();
    }

    @Test
    @DisplayName("DistancesRequest builds a response")
    public void testRequestBuild() {
        distances.places = new Places();
        distances.buildResponse();
    }

    @Test
    @DisplayName("DistancesRequest builds a response with one place")
    public void testOnePlace() {
        distances.places = new Places();
        distances.places.add(new Place("40", "40"));
        distances.buildResponse();
    }

    @Test
    @DisplayName("DistancesRequest builds a response with multiple places")
    public void testMultiplePlaces() {
        distances.places = new Places();
        distances.places.add(new Place("40", "40"));
        distances.places.add(new Place("70", "70"));
        distances.buildResponse();
    }
}