package com.tco.database;

import java.lang.reflect.Type;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestDatabaseCredential {
    @Test
    @DisplayName("DatabaseCredential produces an accurate connection string")
    public void testConnectionString() {
        DatabaseCredential credential = new DatabaseCredential("database", "pass", "jdbc:mariadb://faure.cs.colostate.edu/user", "connectTimeout=4000");
        String mockConnectionStr = "jdbc:mariadb://faure.cs.colostate.edu/user?connectTimeout=4000";

        assertEquals(credential.getConnectionStr(), mockConnectionStr);
    }

    @Test
    @DisplayName("DatabaseCredential handles lack of connection string")
    public void testLackOfConnectionProperties() {
        DatabaseCredential credential = new DatabaseCredential("database", "pass", "jdbc:mariadb://faure.cs.colostate.edu/user");
        String mockConnectionStr = "jdbc:mariadb://faure.cs.colostate.edu/user";
        
        assertEquals(credential.getConnectionStr(), mockConnectionStr);
    }

    @Test
    @DisplayName("DatabaseCredential handles null connection string")
    public void testNullConnectionProperties() {
        DatabaseCredential credential = new DatabaseCredential("database", "pass", "jdbc:mariadb://faure.cs.colostate.edu/user", null);
        String mockConnectionStr = "jdbc:mariadb://faure.cs.colostate.edu/user";
        
        assertEquals(credential.getConnectionStr(), mockConnectionStr);
    }
}
