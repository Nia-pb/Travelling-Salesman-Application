package com.tco.requests;
import java.util.ArrayList;
import java.util.HashMap;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;

import com.tco.server.WebApplication;
import com.tco.dataobjects.Places;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class TestFindRequest {

    private FindRequest find;

    @BeforeEach
    public void createFindForTestCases() {
        if (WebApplication.database == null) {
            String port = "31400";
            String[] commandLineArguments = {port};
            WebApplication.main(commandLineArguments);
        }
        
        find = new FindRequest();
    }

    @Test
    @DisplayName("FindRequest builds a response")
    public void testRequestBuild() {
        find.match = "test";
        find.buildResponse();
    }

    @Test
    @DisplayName("FindRequest limit exceeds server limit")
    public void testLimitExceeds() {
        find.match = "James T. Kirk";
        find.limit = 1000000000;
        find.buildResponse();
    }

    @Test
    @DisplayName("FindRequest limit exceeds server limit")
    public void testLimitInBounds() {
        find.match = "Jean-Luc Picard";
        find.limit = 10;
        find.buildResponse();
    }
}