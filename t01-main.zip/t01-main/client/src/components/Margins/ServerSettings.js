import React from 'react';
import { Alert } from 'reactstrap';
import { Button, Col, Container, Input, Modal, ModalBody, ModalFooter, ModalHeader, Row } from 'reactstrap';
import { useServerInputValidation } from '../../hooks/useServerInputValidation';
import { sendAPIRequest } from '../../utils/restfulAPI';


export default function ServerSettings(props) { 
    const [serverInput, setServerInput, config, validServer, resetModal]
        = useServerInputValidation(props.serverSettings.serverUrl, props.toggleOpen);

    function closeModelWithoutSaving(){
        resetModal(props.serverSettings.serverUrl);
    }

    return (
        <Modal isOpen={props.isOpen} toggle={closeModelWithoutSaving}>
            <Header toggleOpen={closeModelWithoutSaving} />
            <Body
                serverInput={serverInput}
                setServerInput={setServerInput} 
                serverSettings={props.serverSettings}
                serverName={getCurrentServerName(config, props.serverSettings)}
                features={getCurrentServerFeatures(config, props.serverSettings)}
                validServer={validServer}   />
            <Footer
                config={config}
                serverInput={serverInput}
                validServer={validServer}
                resetModal={resetModal}
                closeModelWithoutSaving={closeModelWithoutSaving}
                processServerConfigSuccess={props.processServerConfigSuccess}   />
        </Modal>
    );
}


function getCurrentServerName(config, serverSettings) {
    if (config) {
        return config.serverName;
    }
    else if (serverSettings.serverConfig) {
        return serverSettings.serverConfig.serverName;
    }
    return "";
}

function getCurrentServerFeatures(config, serverSettings) {
    var featuresComma;
    if (config) {
        for(var i=0; i < config.features.length; i++){
            featuresComma = config.features.join(", ");
        }
        return featuresComma;
    }
    else if (serverSettings.serverConfig) {
        for(var i=0; i < serverSettings.serverConfig.features.length; i++){
            featuresComma = serverSettings.serverConfig.features.join(", ");
        }
        return featuresComma;
    }
    
    return "";
}

function Header(props) {
    return (
        <ModalHeader className="ml-2" toggle={props.toggleOpen}>
            Server Connection
        </ModalHeader>
    );
}

function Body(props) {
    const urlInput =
        <Input
            value={props.serverInput}
            placeholder={props.serverSettings.serverUrl}
            //onChange={(e) => { switchServer(e.target.value) }}  // <-- TEMP: Calling switchServer method when URL text is changed
            onChange={(e) => { props.setServerInput(e.target.value) }} 
            valid={props.validServer}
            invalid={!props.validServer}
        />;
    // console.log("got here");
    // make sure to calls servers find and config or features label; once functions have been made
    return (
        <ModalBody>
            <Container>
                <SettingsRow label="Name" value={props.serverName} />
                <SettingsRow label="URL" value={urlInput} />
                <SettingsRow label="Features" value={props.features} />              
            </Container>
        </ModalBody>
    );
}

function SettingsRow({label, value}) {
    return (
        <Row className="my-2 vertical-center">
            <Col xs={3}>
                {label}:
            </Col>
            <Col xs={9}>
                {value}
            </Col>
        </Row>
    );
}

function Footer(props){
    let serverIsValid = props.validServer;
    if(serverIsValid){
        return (
            <ModalFooter>
                <Button color="secondary" onClick={props.closeModelWithoutSaving}>Cancel</Button>
                <Button color="primary" onClick={() => {
                    props.processServerConfigSuccess(props.config, props.serverInput);
                    //console.log("save: ", props.serverInput);
                    props.resetModal(props.serverInput);
                }}>Save</Button>
            </ModalFooter>
        );
    }
    else{
        return (
            <ModalFooter>
                <div><Alert color="danger">Invalid Server URL!</Alert></div>
                <Button color="secondary" onClick={props.closeModelWithoutSaving}>Cancel</Button>
                <Button color="primary" disabled={!props.validServer}>Save</Button>
            </ModalFooter>
        );
    }
}


