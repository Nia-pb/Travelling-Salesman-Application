import memberPic from "../../static/images/Placeholder.jpg";
import elitaPic from "../../static/images/elitaPic.jpg";
import johnnyPic from "../../static/images/johnnyPic.png"; // file path will have to be changed (johnny avatar)
import teamPic from "../../static/images/teamimage.jpg";
import niaAvatar from "../../static/images/niaAvatar.png";
import mayaAvatar from "../../static/images/mayaAvatar.jpg";
import nicholasAvatar from "../../static/images/nicholasAvatar.png";
import NikAvatar from "../../static/images/NikAvatar.png";

export const teamData =
    {
        teamName: "TRNG",
        missionStatement: "Inspiring travel logically, passionately, and efficiently, one stop at a time.",
        imagePath: teamPic,
    };


export const memberData = [
    {
        name: "Jonathan Guzman",
        bio: "Jonathan, also known as Johnny, is a junior currently studying Computer Science at CSU. Johnny has not chosen a specific concentration becasue he has many fields of interest. He is intrested in either going into software development, cybersecurity, or human centered computing. Johnny is originally from the mountains and loves to have fun on the slopes. He has many hobbies such as riding horses, snowboarding, DJing, going on trail runs, and starting new business ventures.",
        homeTown: "Vail, CO",
        imagePath: johnnyPic
    },
    {
        name: "Nia Bennabhaktula",
        bio: "Nia, Majoring in Computer Science with Human Centered Computing concentration, as well as a Business minor. Senior at Colorado State University. Interested in arts and nature. Hobbies include painting, hiking and learning new things.",
        homeTown: "Hyderabad, India",
        imagePath: niaAvatar
    },
    {
        name: "Maya Vitrano",
        bio: "Maya is a junior, majoring in Computer Science. Maya will likely have a concentration in Software Engineering. In her free time, she likes playing guitar and ukulele, running, doing yoga, skiing, and beading.",
        homeTown: "Boise, Idaho",
        imagePath: mayaAvatar
    },
    {
        name: "Nik Torraca",
        bio: "Majoring in Computer Science at Colorado State University. Graduated from Pikes Peak Community College with an Associates of Science.  Currently working and living in Colorado Springs. He loves to travel, hike, listen to music and watch/play sports.",
        homeTown: "Holbrook, New York",
        imagePath: NikAvatar
    },
    {
        name: "Elita Danilyuk",
        bio: "Elita, is a junior and is Majoring in Computer Science with a concentration in Software Engineering. Her hobbies include baking, photography, and singing. In her free time, Elita can be found at a café hacking away on her professional and school work.",
        homeTown: "Harrisonburg, Virginia",
        imagePath: elitaPic
    },
    {
        name: "Nicholas Schneider",
        bio: "Nicholas is a senior majoring in computer science. He is currently a software engineer intern for a company in Fort Collins and a research assistant for the CSU Cybersecurity Center. In his free time, Nicholas enjoys listening to music as well as going on walks and hikes in beautiful Colorado.",
        homeTown: "Greeley, Colorado",
        imagePath: nicholasAvatar
    },
];