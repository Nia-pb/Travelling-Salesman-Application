import React, {useState} from 'react'
import { Button, FormGroup, Form, Input, Label, Modal, ModalBody, ModalFooter, ModalHeader, InputGroupButtonDropdown } from 'reactstrap'
import {InputGroup, DropdownToggle, DropdownMenu, DropdownItem } from 'reactstrap'
import { useToggle } from '../../../hooks/useToggle'
import { SaveTrip } from '../../../utils/saveTrip'
import { PREF_FILETYPE } from '../../../utils/constants'
const DEFAULT_FILETYPE = ".json";

export function SaveModal(props){
    const [checked, setChecked] = useState(false);
    const [fileType, setFileType] = useState(checkedFileType());
    const [fileName, setFileName] = useState("");
    const [fileDropdown, toggleFileDropdown] = useToggle(false);

    function close() {
        props.toggle();
        setFileType(checkedFileType);
        setFileName("");
        setChecked(false);
    }

    return (
        <Modal isOpen={props.modal} toggle={close}>
            <ModalHeader toggle={props.toggle}>Save Trip</ModalHeader>
            <ModalBody>
                <Form>
                    <FormGroup><FileNameTypeForm tripName={props.tripName} fileDropdown={fileDropdown} toggleFileDropdown={toggleFileDropdown} fileType={fileType} setFileName={setFileName} setFileType={setFileType}/></FormGroup>
                    <FormGroup check inline>
                        <Label check><Input type="checkbox" onClick={() => setChecked(!checked)}/>Remember {fileType} as default format</Label>
                    </FormGroup>
                </Form>
            </ModalBody>
            <ModalFooter><Button color="primary" onClick={() => downloadTrip({fileName, fileType, setFileType, checked, close, ...props})}>Download</Button></ModalFooter>
        </Modal>
    )
}

function downloadTrip(props){
    SaveTrip(props);
    if(props.checked == true){
        localStorage.setItem(PREF_FILETYPE, props.fileType);
      }

    props.close();
}

function checkedFileType(){
    let pref = localStorage.getItem(PREF_FILETYPE);
    if (pref != null && (pref == ".json" || pref == ".csv" || pref == ".svg" || pref == ".kml")) {
        return pref;
    }
    return DEFAULT_FILETYPE;
}

function FileNameTypeForm(props) {
    return (
        <InputGroup>
            <Input placeholder={props.tripName} type="text" onChange={ (e) => props.setFileName(e.target.value)} />
            <InputGroupButtonDropdown addonType="append" isOpen={props.fileDropdown} toggle={props.toggleFileDropdown}>
                <DropdownToggle caret>
                    {props.fileType}
                </DropdownToggle>
                <DropdownMenu>
                    <DropdownItem onClick={ () => props.setFileType(".json")}> .json</DropdownItem>
                    <DropdownItem onClick={ () => props.setFileType(".csv")}> .csv</DropdownItem>
                    <DropdownItem onClick={ () => props.setFileType(".svg")}> .svg</DropdownItem>
                    <DropdownItem onClick={ () => props.setFileType(".kml")}> .kml</DropdownItem>
                </DropdownMenu>

            </InputGroupButtonDropdown>
        </InputGroup>
    );
}