import React from "react";
import { ModalHeader, ModalBody, ModalFooter, Button, Modal } from "reactstrap";
import { ShortenTripUtil } from '../../../utils/tour';

export function TourModal(props) {
    return (
        <Modal isOpen={props.toggled} toggle={props.toggle} data-testid="tour-modal">
            <ModalHeader toggle={props.toggle}>Tour</ModalHeader>
            <ModalBody>
                <p> Are you sure you want to optimize your trip? </p>
            </ModalBody>
            <ModalFooter>
                <Button color="primary" onClick={() => shortenTrip(props)} >Optimize</Button>
                <Button color="primary" onClick={props.toggle}>Close</Button>
            </ModalFooter>
        </Modal>
    )
}

export function shortenTrip(props) {
    ShortenTripUtil(props);
}