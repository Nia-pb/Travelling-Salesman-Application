import React from 'react'
import { ButtonGroup, DropdownItem, DropdownMenu, DropdownToggle, UncontrolledDropdown, Input, InputGroup, InputGroupAddon} from 'reactstrap'
import { BiDotsVerticalRounded } from 'react-icons/bi'
import { FaHome, FaTrash, FaTrashAlt, FaPlus, FaFileImport, FaSave, FaCarSide } from 'react-icons/fa'
import { DEFAULT_STARTING_PLACE } from '../../../utils/constants'
import { ImMoveUp } from 'react-icons/im'


const FILE_FORMATS = ".json, .csv, application/json, text/csv";

export function ItineraryActionsDropdown(props) {
    return (
        <ActionsDropdown {...props}>
            <DropdownItem onClick={() => props.placeActions.moveToHome()} data-testid='home-button'>
                <FaHome />
            </DropdownItem>
            <DropdownItem onClick={props.toggleLoadModal} data-testid='load-button'>
                <FaFileImport />
             </DropdownItem>
             <DropdownItem onClick={props.toggleSaveModal} data-testid='save-button'>
                <FaSave />
            </DropdownItem>
            <DropdownItem onClick={props.toggleTourModal} data-testid='tour-button'>
                <FaCarSide />
            </DropdownItem>
            <DropdownItem onClick={() => confirmDelete(props)}data-testid='delete-all-button'>
                <FaTrashAlt />
            </DropdownItem>
        </ActionsDropdown>
    );
}

export function PlaceActionsDropdown(props) {
    return (
        <ActionsDropdown {...props}>
            <DropdownItem onClick={() => props.placeActions.moveToStart(props.index)} data-testid={`moveToStart-button-${props.index}`}>
                <ImMoveUp />
            </DropdownItem>
            <DeleteButton {...props}></DeleteButton>
        </ActionsDropdown>
    );
}

function ActionsDropdown(props) {
    return (
        <UncontrolledDropdown direction="left">

            <DropdownToggle tag="div" data-testid={`row-toggle-${props.index}`}>
                <BiDotsVerticalRounded size="1.5em" />
            </DropdownToggle>
            <DropdownMenu>
                <ButtonGroup>
                    {props.children}
                </ButtonGroup>
            </DropdownMenu>
        </UncontrolledDropdown>
    );
}

function DeleteButton(props) {
    return (
        <DropdownItem onClick={() => props.placeActions.removeAtIndex(props.index)} data-testid={`delete-button-${props.index}`}>
            <FaTrash />
        </DropdownItem>
        
    );
}

function confirmDelete(props){
    var confirmDelete = confirm("Are you sure you want to delete your trip?");
    if (confirmDelete == true) {
      props.placeActions.removeAll();
    }
}