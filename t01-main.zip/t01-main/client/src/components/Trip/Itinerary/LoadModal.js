import React, {useState} from "react";
import { ModalHeader, ModalBody, ModalFooter, Button, Modal } from "reactstrap";
import { useDropzone } from 'react-dropzone';
import { loadFile } from "../../../utils/loadIO";


export function LoadModal(props) {
    const [fileState, setFileState] = useState();
    const {acceptedFiles, getRootProps, getInputProps} = useDropzone({
        onDrop: ([file]) => onUpload([file], {setFileState, toggleModal, ...props}), 
        multiple: false   
    });
    var uploadText = "Drag or click to upload file here.";
    var classes = 'dropzone';
    if(fileState == "uploaded"){
        classes+=' dropzone-uploaded';
        uploadText = "File successfully uploaded.";
    }
    else if(fileState == "invalid") {
        classes+=' dropzone-invalid';
        uploadText = "Invalid file uploaded.";
    }
    return (
    <Modal isOpen={props.toggled} toggle={() => toggleModal({setFileState, ...props})} data-testid="load-modal">
        <ModalHeader toggle={() => toggleModal({setFileState, ...props})}>Upload Trip</ModalHeader>
        <ModalBody><ModalBodyDiv getRootProps = {getRootProps} getInputProps = {getInputProps} classes = {classes} uploadText = {uploadText}></ModalBodyDiv></ModalBody>
        <ModalFooter><Button color="secondary" onClick={() => toggleModal({setFileState, ...props})}>Close</Button></ModalFooter>
    </Modal>
    );
}

function onUpload([file], props) {
    var reader = new FileReader();
    reader.onload = function (e) {
        let fileContents = e.target.result;
        loadFile(fileContents, props);
    }
    reader.readAsText(file);
    props.setFileState("uploaded");
}

function toggleModal(props) {
    props.setFileState(null);
    props.toggle();
}

function ModalBodyDiv(props){
    return(
        <div {...props.getRootProps({className: 'dropzone'})} className={props.classes}>
            <input {...props.getInputProps()} data-testid="dropzone-input" />
            {props.uploadText}<br/>
            <small>Supports: *.csv, *.json</small>
        </div>
    );
}