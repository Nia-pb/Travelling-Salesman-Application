import React, {useState} from 'react';
import { Button, ButtonGroup, DropdownItem, InputGroup, NavItem, Table } from 'reactstrap';
import { ItineraryActionsDropdown, PlaceActionsDropdown, TripName } from './actions.js';
import { latLngToText, latLngToPlace } from '../../../utils/transformers';
import { Distances } from '../Distances/Distances';
import { useToggle } from '../../../hooks/useToggle';
import { LoadModal } from './LoadModal';
import { SaveModal } from './SaveModal';
import { TourModal } from './TourModal';
import { EditText } from 'react-edit-text';
import { FaEdit, FaArrowAltCircleDown, FaArrowAltCircleUp } from 'react-icons/fa'
import { RiArrowUpDownFill, RiSortAsc } from 'react-icons/ri'
import { reverseTrip } from '../../../utils/reverseGeocode.js';
import ShowMoreText from "react-show-more-text";


export default function Itinerary(props) {

    const [tripName, setTripName] = useState("My Trip");
    const [saveModal, toggleSaveModal] = useToggle(false);
    const [loadModal, toggleLoadModal] = useToggle(false);
    const [tourModal, toggleTourModal] = useToggle(false);
  
    return (
        <Table responsive striped>
            <SaveModal tripName={tripName} distances={props.distances} modal={saveModal} toggle={toggleSaveModal} places={props.places} placeActions={props.placeActions}/>
            <LoadModal toggled={loadModal} toggle={toggleLoadModal} placeActions={props.placeActions} showMessage={props.showMessage} distancesActions={props.distancesActions} />
            <TourModal toggled={tourModal} toggle={toggleTourModal} serverSettings={props.serverSettings} places={props.places} placeActions={props.placeActions} showMessage={props.showMessage} />
            <Header tripName={tripName} setTripName={setTripName} placeActions={props.placeActions} places={props.places} loadModal={loadModal} toggleLoadModal={toggleLoadModal} saveModal={saveModal}
                 toggleSaveModal={toggleSaveModal} toggleTourModal={toggleTourModal} distances={props.distances} distancesActions={props.distancesActions}/>
            <Body selectedIndex={props.selectedIndex} distances={props.distances} places={props.places} placeActions={props.placeActions} />
        </Table>
    );
}

function Header(props) {
    const handleName = (e) => {
        props.setTripName(e);
    };  
    var lodash = require('lodash');
    return (
        <thead>
            <tr> 
                <th colSpan="2">
                    <InputGroup>
                        <FaEdit/><EditText placeholder="My Trip" type="text" value={props.tripName} onChange={handleName}/> 
                    </InputGroup>
                    <small className="total"> Total Distance: {lodash.sum(props.distances)}</small>
                </th>
                <th className="reverse" colSpan="2">
                    <RiArrowUpDownFill className="icon" onClick={() => reverseTrip(props)} data-testid='reverse-button'/>  
                </th>
                <th className="left">
                    <ItineraryActionsDropdown placeActions={props.placeActions} loadModal={props.loadModal} toggleLoadModal={props.toggleLoadModal} saveModal={props.saveModal} toggleSaveModal={props.toggleSaveModal} toggleTourModal={props.toggleTourModal} />
                </th>
            </tr>
        </thead>
    );
}

function Body(props) {
    
    return (
      <>
        {props.places.map((place, index) => 
        <tbody key={`table-${JSON.stringify(place)}-${index}`} className={index==props.selectedIndex ? "selectedRow" : ""}> 
            <TableRow 
                
                place={place}
                placeActions={props.placeActions}
                index={index}
                places={props.places}
                distances={props.distances}
                selectedIndex={props.selectedIndex}/>  

        </tbody>
        )}
    </>
    )
}

function TableRow(props) {
    const name = props.place.name ? props.place.name : "-";
    const location = latLngToText(props.place);
    function executeOnClick(isExpanded) {
    }
    return (
         <tr onClick={ () =>  props.placeActions.selectIndex(props.index)} >
            <th scope="row">{props.index + 1}</th>
           
            <td>
                <ShowMoreText
                lines={1}
                more= "Show more"
                less="Show less"
                onClick={executeOnClick()}
                expanded={false}
                truncatedEndingComponent={"... "}>
                  
                {name} <br/>
                <small className="text-muted">{location}</small> <br/>
                <Distances distances={props.distances} index={props.index}/><br/>
                </ShowMoreText>
            </td> <br/>
            <td>  <FaArrowAltCircleUp onClick={ () =>  props.placeActions.moveUp(props.index, props.index+1)}/> <FaArrowAltCircleDown onClick={ () =>  props.placeActions.moveDown(props.index, props.index+1)}/> </td>
            <td>  <PlaceActionsDropdown placeActions={props.placeActions} index={props.index} /></td> 
        </tr>  
    );
}
