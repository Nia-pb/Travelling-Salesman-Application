
import React, { useState } from 'react'
import { Col, Container, Row } from 'reactstrap'
import Map from './Map/Map'
import Itinerary from './Itinerary/Itinerary'
import SearchBar from './Find/SearchBar'
import SearchResults from './Find/SearchResults'
import { usePlaces } from '../../hooks/usePlaces'
import { useFind } from '../../hooks/useFind'
import { useDistances } from '../../hooks/useDistances'

export default function Planner(props) {
    const {places, selectedIndex, placeActions} = usePlaces();
    const {distances, distancesActions} = useDistances(places, props.serverSettings);
    const {findResults, findActions} = useFind();
   
    return (
        <Container>
            <Section>
                <SearchBar serverSettings={props.serverSettings} findResults={findResults} findActions={findActions} />
                <SearchResults findResults={findResults} findActions={findActions} placeActions={placeActions} showMessage={props.showMessage} />
            </Section>
            <br/>
            <Section>
                <Map places={places} selectedIndex={selectedIndex} placeActions={placeActions} />
            </Section>
            <Section>
                <Itinerary distances={distances} distancesActions={distancesActions} places={places} selectedIndex={selectedIndex} placeActions={placeActions} showMessage={props.showMessage} serverSettings={props.serverSettings}  /> 
            </Section>
            
        </Container>
    );
}

function Section(props) {
    return (
        <Row>
            <Col sm={12} md={{ size: 10, offset: 1 }}>
                {props.children}
            </Col>
        </Row>
    );
}
