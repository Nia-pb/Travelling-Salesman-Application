import React, { useEffect, useState } from 'react';


export  function Distances(props) {
    if(props.distances == null){
        return (
       
            <small className="distAtzero"> Distance: no distance </small>
            
       );
    } 
    else{
        return(
                <small className="Distance"> Distance: {props.distances[props.index]}</small>
    
        )
    }
};
