
import React, { useState } from 'react'
import { InputGroup, Input, Button, InputGroupAddon } from 'reactstrap'
import { sendAPIRequest } from '../../../utils/restfulAPI'
import { MdClear } from 'react-icons/md';
import { FaSearchLocation } from 'react-icons/fa';

export default function SearchBar(props) {
    const [searchTerm, setSearchTerm] = useState("");

    const handleKeypress = e => {
        if (e.key === 'Enter') {
            search({searchTerm, ...props});
        }
    };
  
    return (
        <InputGroup>
            <Input placeholder="Search for an airport/heliport..." type="text" onKeyPress={handleKeypress} value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="input-clear" />
            <InputGroupAddon addonType="append">
                <Button onClick={() => clearSearch({setSearchTerm, ...props})} className="input-clear-button" title="Clear Results">
                    <MdClear color="black" size={18} />
                </Button>
                <Button onClick={() => search({searchTerm, ...props})} color="primary" title="Search for a Place" data-testid="search-icon">
                    <FaSearchLocation />
                </Button>
            </InputGroupAddon>
        </InputGroup>
    );
}

async function search(props) {
    const requestBody = { requestType: "find", match: props.searchTerm, limit: 100 };
    const findResponse = await sendAPIRequest(requestBody, props.serverSettings.serverUrl);
    props.findActions.setResults(findResponse.places);
}

function clearSearch(props) {
    props.setSearchTerm("");
    props.findActions.removeAll();
}