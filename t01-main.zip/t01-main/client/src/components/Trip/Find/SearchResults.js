import React from 'react';
import { Table, Button, Badge } from 'reactstrap';
import { placeResultToLocation } from '../../../utils/transformers';
import { FaPlus } from 'react-icons/fa';

export default function SearchResults(props) {
    return (
        <div className="find-search-results">
            <Table responsive striped> 
                <Header />
                <Body findResults={props.findResults} placeActions={props.placeActions} showMessage={props.showMessage} />
            </Table>
        </div>
    );
}

function Header(props) {
    return (
        <thead>
            <tr>
                <th>Search Results</th>
            </tr>
        </thead>
    );
}

function Body(props) {
     return (
        <tbody>
           {props.findResults.map((place, index) => 
                <TableRow 
                    key={`table-${JSON.stringify(place)}-${index}`}
                    place={place}
                    placeActions={props.placeActions}
                    index={index}
                    findResults={props.findResults}
                    showMessage={props.showMessage}
                />
            )}
        </tbody>
    );
}

function addPlace(props) {
    let place = props.findResults[props.index];

    props.placeActions.append(place);
    props.showMessage(<>Added <Badge color="secondary">{place.name}</Badge> to your trip!</>, "success");
}


function TableRow(props) {
   var name;

    if (props.place) {
        name = props.place.name ? props.place.name : "-";
    }

    var location = placeResultToLocation(props.place);
 
    return (
        <tr>
            <td>
                {name}
                <br/>
                <small className="text-muted">{location}</small>
            </td>
            <td>
                <Button onClick={() => addPlace(props)} color="primary">
                    <FaPlus title="Add to Trip" />
                </Button>
            </td>
        </tr>
    );
}
