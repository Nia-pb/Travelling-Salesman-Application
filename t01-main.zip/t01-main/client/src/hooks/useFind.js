import { useState } from 'react';

export function useFind() {
    const [findResults, setResults] = useState([]);

    const context = {findResults, setResults};

    const findActions = {
        setResults,
        removeAll: () => removeAll(context)
    };

    return {findResults, findActions};
}

function removeAll({setResults}) {
    setResults([]);
}