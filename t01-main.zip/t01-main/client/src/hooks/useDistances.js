import React, { useEffect, useRef, useState } from 'react'
import { latLngToPlace } from '../utils/transformers'
import {sendAPIRequest} from '../utils/restfulAPI'

export  function useDistances(places, serverSettings) {
    const [distances, setDistances] = useState([]);

    const context = {distances, places, setDistances};

    if(places.length > 1 && places.length != distances.length){
        getDistances(serverSettings.serverUrl, context);
    }
    const distancesActions = {
        setDistances,
        removeAllDistances: () => removeAllDistances(context),

    }
    return {distances, distancesActions}
};

function removeAllDistances(context) {
    const { setDistances } = context;
    setDistances([]);
}

 async function getDistances(serverUrl, context){
    const newplaces = [];
    for(let i = 0; i < context.places.length; i++) {
        const fullPlace = (latLngToPlace(context.places[i]));
        newplaces.push(fullPlace);
    }

    const requestBody = { requestType: "distances", places: newplaces , earthRadius: 3959};
    const configResponse = await sendAPIRequest(requestBody, serverUrl);
    
    context.setDistances(configResponse.distances);
    
}

