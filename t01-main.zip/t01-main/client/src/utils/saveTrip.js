//import { DEFAULT_TRIP_NAME } from "./constants";
import { latlonToFull } from "./transformers";
const MIME_TYPE = {
    JSON: "application/json",
    CSV: "text/csv",
    SVG: "image/svg+xml",
    KML: "application/vnd.google-earth.kml+xml"
};

export function SaveTrip(props) {

    var tripName = checkFileName(props);
    var fileType = props.fileType;
    const fileName = tripName.replace(/ /g, "_").toLowerCase();

    try {
        if(fileType == '.csv'){
            var tripCSV = buildTripCSV(props);
            downloadFile(fileName + fileType, getMimeType(fileType), tripCSV);
        }

        if(fileType == '.json'){
            const tripJSON = buildTripJSON(props);
            downloadFile(fileName + fileType, getMimeType(fileType), tripJSON);
        }

        if(fileType == '.svg'){
            var tripSVG = buildTripSVG(props);
            downloadFile(fileName + fileType, getMimeType(fileType), tripSVG);
        }

        if(fileType == '.kml'){
            var tripKML = buildTripKML(props);
            downloadFile(fileName + fileType, getMimeType(fileType), tripKML);
        }
    } catch (error) { }
    
}

function checkFileName(props) {
    if (props.fileName) {
        return props.fileName;
    }

    return props.tripName;
}

function getMimeType(fileType) {
    try {
        if (fileType == '.csv') {
            return MIME_TYPE.CSV;
        } else if (fileType == '.json') {
            return MIME_TYPE.JSON;
        } else if (fileType == '.svg') {
            return MIME_TYPE.SVG;
        } else if (fileType == '.kml') {
            return MIME_TYPE.KML;
        }
    } catch (error) {}
}

export function downloadFile(fileNameWithExtension, mimeType, fileText) {
    const file = new Blob([fileText], { type: mimeType });
    const link = document.createElement("a");
    const url = URL.createObjectURL(file);
    link.href = url;
    link.download = fileNameWithExtension;
    document.body.appendChild(link);
    link.click();
    setTimeout(function() {
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
    }, 0);
}

export function buildTripJSON(props) {
    const newPlaces = latlonToFull(props.places);
    const tripJSON = {
        places: newPlaces,
        distances: props.distances,
        earthRadius: 3959,
        units: "km" 
    };
    return JSON.stringify(tripJSON, null, 2); // Turn the object into a string with a spacing of 2 for readability.
}

export function buildTripCSV(props) {
    var csv;
    csv = "name,latitude,longitude,distance \r\n";
    for(let i = 0; i < props.places.length; i++){
        csv += '"' + props.places[i].name + '"' + "," + '"' + props.places[i].lat +  '"' + "," + props.places[i].lng+ "," + props.distances[i];

        if(i != (props.places.length-1) ){
            csv += "\r\n";
        }
    }
    return csv;
}

export function buildTripSVG(props){
    var svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1440" height="720" viewBox="-180 -90 360 180">\n` +
            `\t<image href="https://instructor-uploaded-content.s3.amazonaws.com/MAP.svg-6983777" x="-180" y="-90" height="180" width="360"/>\n` +
            `\t<g transform="matrix(1,0,0,-1,0,0)">\n`;
     
    var tripCoordinates="";
    for(let i = 0; i < props.places.length; i ++){
        svg += `<circle cx="${props.places[i].lng}" cy="${props.places[i].lat}" r="0.75" stroke="rgb(59, 110, 60)" stroke-width="0.25" fill="rgb(59, 110, 60)"/>`;
    
        tripCoordinates += `\t\t\t${props.places[i].lng},${props.places[i].lat}\n`;
    }
    tripCoordinates += `\t\t\t${props.places[0].lng},${props.places[0].lat}`;

    svg += `\t\t\t<polyline points="\n${tripCoordinates}"\n\t\t\tstyle="fill:none; stroke:rgb(59, 110, 60); stroke-width:0.5"/>\n`;

    svg += `\t</g>\n</svg>`;

    return svg;
}

export function buildTripKML(props) {
    var kml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
            "<kml xmlns=\"http://earth.google.com/kml/2.0\">\n" + 
            "\t<Document>\n";

    kml += "\t\t<Style id=\"TRNGLineStyle\"><LineStyle><color>1E4D2B</color><width>2</width></LineStyle></Style>\n";

    var tripCoordinates="";

    for(let i = 0; i < props.places.length; i++){
        kml += "\t\t<Placemark>\n";
        kml += "\t\t\t<name>" + props.places[i].name + "</name>\n";
        kml += "\t\t\t<Point><coordinates>" + props.places[i].lng + ","+ props.places[i].lat + "</coordinates></Point>\n";
        kml += "\t\t</Placemark>\n";

        tripCoordinates += props.places[i].lng + ","+ props.places[i].lat + " \n\t\t\t\t";
    }

    tripCoordinates += props.places[0].lng + ","+ props.places[0].lat + " \n\t\t\t\t";

    kml += createLinePath(tripCoordinates);

    kml += "\t</Document>\n" + 
            "</kml>";

    return kml;
}

function createLinePath(coordinates){
    var kmlPath = "\t\t<Placemark>\n" +
            "\t\t\t<ExtendedData>\n\t\t\t\t<Data name=\"stroke\"><value>#38f</value></Data><Data name=\"stroke-width\"><value>2</value></Data>\n\t\t\t</ExtendedData>\n" +
            "\t\t\t<LineString><coordinates>\n\t\t\t\t" + coordinates + "</coordinates></LineString>\n" + 
            "\t\t\t<styleUrl>#TRNGLineStyle</styleUrl>\n" +
            "\t\t</Placemark>\n";

    return kmlPath;
}