import React from 'react';
import { Badge } from 'reactstrap';
import Papa from 'papaparse';
import { isJsonResponseValid } from './restfulAPI';
import * as tripFileSchema from '../../schemas/TripFile';
import { jsonPlacesLatLng } from './transformers';

export function loadFile(file, context) {
    if (isValidTripJsonFile(file)) {
        readJSON(file, context);
    } else {
        readCSV(file, context);
    }
}

function isValidTripJsonFile(file) {
    try {
        var tripJson = JSON.parse(file);
        return isValidTripJson(tripJson);
    } catch { }

    return false;
}

function isValidTripJson(json) {
    return isJsonResponseValid(json, tripFileSchema);
}

function readJSON(file, context) {
    try {
        var tripJson = JSON.parse(file, jsonPlacesLatLng);

        context.placeActions.setPlaces(tripJson.places);

        if ("distances" in tripJson) {
            context.distancesActions.setDistances(tripJson.distances);
        } else {
            context.distancesActions.setDistances([]);
        }

        return tripLoadSuccessMessage("JSON", context);
    } catch {}

    tripLoadErrorMessage("JSON", context);
}

function readCSV(file, context) {
    try {
        let tripJson = {places: []};
        let places = [];
        let distances = [];

        Papa.parse(file, {
            header: true,
            step: (row) => stepCSV(row, {places, distances, tripJson}), 
            error: () => tripLoadErrorMessage("CSV", context), 
            complete: () => completeCSV({places, distances, tripJson}, context) 
        });
    } catch {
        tripLoadErrorMessage("CSV", context);
    }
}

function stepCSV(row, {places, distances, tripJson}) {
    tripJson.places.push(row.data);

    let place = {};

    for (let index in row.data) {
        let value = row.data[index];

        if (index == "distances") {
            distances.push(parseFloat(value));
        } else if (index == "latitude") {
            place["lat"] = parseFloat(value);
        } else if (index == "longitude") {
            place["lng"] = parseFloat(value);
        } else {
            place[index] = value;
        }
    }

    places.push(place);
}

function completeCSV({places, distances, tripJson}, context) {
    try {
        if (isValidTripJson(tripJson)) {
            context.placeActions.setPlaces(places);
            context.distancesActions.setDistances(distances);
            return tripLoadSuccessMessage("CSV", context);
        }
    } catch {}

    tripLoadErrorMessage("CSV", context);
}

function tripLoadSuccessMessage(type, {showMessage, toggleModal, setFileState, toggle}) {
    toggleModal({setFileState, toggle});
    showMessage(<>Successfully loaded <Badge color="secondary">{type}</Badge> trip file.</>, "success");
}

function tripLoadErrorMessage(type, {showMessage, setFileState}) {
    setFileState("invalid");
    showMessage(<>Error while loading <Badge color="secondary">{type}</Badge> trip file. Be sure the trip file format is valid.</>, "error");
}