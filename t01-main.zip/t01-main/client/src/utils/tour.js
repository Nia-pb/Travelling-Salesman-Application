import React, { useState } from 'react'
import { BiUndo } from 'react-icons/bi';
import { Button } from 'reactstrap';
import {getOriginalServerUrl, sendAPIRequest} from '../utils/restfulAPI'
import { latLngToPlace } from '../utils/transformers'
import { placeToLatLng } from '../utils/transformers'
import { LOG } from './constants';

export function ShortenTripUtil(props) {
    tourAPICall(props);
}

async function tourAPICall(props) {
    const ourServerURL = props.serverSettings.serverUrl;
    const ourPlaces = [];

    for(let i = 0; i < props.places.length; i++) {
        const fullPlace = (latLngToPlace(props.places[i]));
        ourPlaces.push(fullPlace);
    }

    const originalPlaces = props.places;

    const requestBody = { requestType: "tour", earthRadius: 3959, response: 1, places: ourPlaces};
    const tourResponse = await sendAPIRequest(requestBody, ourServerURL);

    handleTourApiCall(tourResponse, originalPlaces, props)
}

export function handleTourApiCall(response, originalPlaces, props) {
    if (response) {
        const newPlaces = [];

        for(let i = 0; i < response.places.length; i++) {
            const fullPlace = (placeToLatLng(response.places[i]));
            if (response.places[i].name != null) {
                fullPlace.name = response.places[i].name;
            }

            newPlaces.push(fullPlace);
        }

        props.placeActions.setPlaces(newPlaces);
    }
    else{
        LOG.error("Error could not handle tour request!");
    }

    props.showMessage(<>The trip has been optimized. <Button onClick={() => revertTour(originalPlaces, props)} color="primary">Undo <BiUndo size={18} /></Button></>, "success");
    props.toggle();
}

export function revertTour(originalPlaces, {placeActions, showMessage}) {
    placeActions.setPlaces(originalPlaces);
    showMessage(<>The original trip has been restored.</>, "success");
} 