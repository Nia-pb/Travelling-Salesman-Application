export function latLngToText(latLng, precision = 2) {
    return latLng ? `${latLng.lat.toFixed(precision)}, ${latLng.lng.toFixed(precision)}` : "";
}

export function placeToLatLng(place) {
    return place ? { lat: parseFloat(place.latitude), lng: parseFloat(place.longitude) } : place;
}

export function latLngToPlace(latLng) {
    return  latLng ? {name: latLng.name, latitude: latLng.lat.toString(), longitude: latLng.lng.toString() } : latLng;
}


export function latlonToFull(places){
    const newPlaces = [];
    for(let i = 0; i < places.length; i++){
        const fullPlace =  (latLngToPlace(places[i]));
        newPlaces.push(fullPlace);
    }
    return newPlaces;
}

// For use in JSON.parse(content, jsonLatLngPlaces)
export function jsonLatLngPlaces(key, value) {
    if (key == "lat") {
        this.latitude = value.toString();
    }
    else if (key == "lng" ) {
        this.longitude = value.toString();
    }
    else {
        return value;
    }
}

// For use in JSON.parse(content, jsonPlacesLatLng)
export function jsonPlacesLatLng(key, value) {
    if (key == "latitude") {
        this.lat = parseFloat(value);
    }
    else if (key == "longitude" ) {
        this.lng = parseFloat(value);
    }
    else {
        return value;
    }
}

export function placeResultToLocation(place) {
    var location = "";
    var fields = ["municipality", "region", "country"];
    let isFirst = true;
    for (const field of fields) {
        if (place[field] != null) {
            if (!isFirst) {
                location += ", ";
            } else {
                isFirst = false;
            }
            location += place[field];
        }
    }
    if (location == "") {
        location = latLngToText({lat: parseFloat(place.latitude), lng: parseFloat(place.longitude)});
    }
    return location;
}