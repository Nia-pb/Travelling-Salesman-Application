import { beforeEach, describe, it, jest } from '@jest/globals';
import { loadFile } from '../../src/utils/loadIO.js';
import { MOCK_TRIPFILE_JSON, MOCK_TRIPFILE_CSV, MOCK_JSON_NO_DIST, MOCK_INVALID_CSV, MOCK_DISTANCE_CSV} from '../sharedMocks';

describe('loadIO', () => {

    const context = { placeActions:{
                        setPlaces:jest.fn()
                      }, 
                      distancesActions:{
                        setDistances:jest.fn()
                      },
                      showMessage:jest.fn(),
                      toggleModal:jest.fn(),
                      setFileState:jest.fn(),
                      toggle:jest.fn()                   
                                            };
    const jsonFile = MOCK_TRIPFILE_JSON;
    const jsonNoDist = MOCK_JSON_NO_DIST;
    const csvFile = MOCK_TRIPFILE_CSV;
    const csvInvalid = MOCK_INVALID_CSV;
    const csvDistance = MOCK_DISTANCE_CSV;

    it('Successfully reads JSON file', () => {
        loadFile(jsonFile, context);
    });

    it('Successfully reads JSON file without distances', () => {
        loadFile(jsonNoDist, context);
    });

    it('Successfully reads CSV file', () => {
        loadFile(csvFile, context);
    });

    it('Successfully handles invalid CSV file', () => {
        loadFile(csvInvalid, context);
    });

    it('Successfully handles CSV file with distances', () => {
        loadFile(csvDistance, context);
    });
});