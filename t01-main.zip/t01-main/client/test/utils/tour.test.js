import { describe, it, jest } from '@jest/globals';
import { ShortenTripUtil, handleTourApiCall, revertTour } from '../../src/utils/tour';
import { MOCK_PLACES } from '../sharedMocks';

describe('tour', () => {
    const serverSettings = {
        serverUrl: ""
    };
    const placeActions = {
        setPlaces: jest.fn()
    };
    const showMessage = jest.fn();
    const toggle = jest.fn();
    const MOCK_RESPONSE = {
        places: MOCK_PLACES
    };

    it('Shortens a trip', async () => {
        fetch.mockResponse(MOCK_RESPONSE);
        ShortenTripUtil({
            serverSettings,
            places: MOCK_PLACES,
            showMessage,
            placeActions
        });
    });

    it('Handles a tour API call', () => {
        handleTourApiCall(MOCK_RESPONSE, MOCK_PLACES, {showMessage, toggle, placeActions});
    });

    it('Handles an invalid tour API call', () => {
        handleTourApiCall(false, MOCK_PLACES, {showMessage, toggle, placeActions});
    });

    it('Reverts on undo', () => {
        revertTour(MOCK_PLACES, {placeActions, showMessage});
    });
});