import React from 'react';
import { render, screen } from '@testing-library/react';
import { beforeEach, describe, it, jest } from '@jest/globals';
import { LOG } from '../../src/utils/constants';
import { SaveTrip, downloadFile, buildTripJSON, buildTripCSV, latlonToFull } from '../../src/utils/saveTrip.js';
import { MOCK_PLACES } from '../sharedMocks';

describe ('saveTrip', () => {

    it("Saves a trip as a json file", () => {
        const context = { fileType: ".json", 
                        fileName: "myTrip",
                        tripName: "myTrip",
                        distances: [1,1],
                        places: MOCK_PLACES

        }
        SaveTrip(context);

    });

    it("Saves a trip as a csv file", () => {
        const context = { fileType: ".csv", 
                        fileName: "myTrip",
                        tripName: "myTrip",
                        distances: [1,1],
                        places: MOCK_PLACES

        }
        SaveTrip(context);

    });

    it("Saves a trip as a svg file", () => {
        const context = { fileType: ".svg", 
                    fileName: "myTrip",
                    tripName: "myTrip",
                    distances: [1,1],
                    places: MOCK_PLACES
        }
        SaveTrip(context);
    });

    it("Saves a trip as a kml file", () => {
        const context = { fileType: ".kml", 
                    fileName: "myTrip",
                    tripName: "myTrip",
                    distances: [1,1],
                    places: MOCK_PLACES
        }
        SaveTrip(context);
    });
    
    it("Save trip as default name", () => {
        jest.useFakeTimers();
        const context = { fileType: ".csv", 
                        tripName: "myTrip",
                        distances: [1,1],
                        places: MOCK_PLACES
                        
        }
        SaveTrip(context);
        jest.runOnlyPendingTimers();
    });
});