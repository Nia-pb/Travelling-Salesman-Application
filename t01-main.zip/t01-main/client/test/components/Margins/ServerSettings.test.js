import React from 'react';
import { act, render, screen, waitFor } from '@testing-library/react';
import user from '@testing-library/user-event';
import { expect, it } from '@jest/globals';
import { VALID_CONFIG_RESPONSE, INVALID_REQUEST } from '../../sharedMocks';
import { LOG } from '../../../src/utils/constants';
import ServerSettings from '../../../src/components/Margins/ServerSettings';

describe('Server Settings Modal', () => {
    const validUrl = 'http://localhost:8000';
    const invalidUrl = 'BAD URL';
    const serverSettings = { 'serverUrl': validUrl, 'serverConfig': null };
    const toggleOpen = jest.fn();
    const processServerConfigSuccess = jest.fn();

    let inputBox;
    let saveButton;

    beforeEach(() => {
        jest.clearAllMocks();
        fetch.resetMocks();

        jest.spyOn(LOG, 'error').mockImplementation(() => {});
        fetch.mockResponse(VALID_CONFIG_RESPONSE);

        render(<ServerSettings
            isOpen={true}
            serverSettings={serverSettings}
            toggleOpen={toggleOpen}
            processServerConfigSuccess={processServerConfigSuccess}
        />);

        inputBox = screen.getByDisplayValue(validUrl);
        saveButton = screen.getByRole('button', { name: /save/i });

        act(() => {
            user.clear(inputBox);
        });
    });

    it('updates input text onChange and disables save button with invalid url', async () => {
        user.type(inputBox, invalidUrl);

        await waitFor(() => {
            expect(inputBox.value).toEqual(invalidUrl);
            expect(saveButton.classList.contains('disabled')).toBe(true);
        });
    });

    it('Does not update input text onChange and enables save button with valid URL', async () => {
        user.type(inputBox, validUrl);

        await waitFor(() => {
            expect(inputBox.value).toEqual(validUrl);
        });
    });

    it('disables save button on invalid Config response from url', async () => {
        fetch.mockResponseOnce(INVALID_REQUEST);

        user.type(inputBox, validUrl);

        await waitFor(() => {
            expect(saveButton.classList.contains('disabled')).toBe(true);
        });
        expect(LOG.error.mock.calls.length).toBeGreaterThanOrEqual(1);
    });

    it('enables save button on valid Config response from url', async () => {
        fetch.mockResponseOnce(VALID_CONFIG_RESPONSE);

        user.type(inputBox, invalidUrl);

        await waitFor(() => {
            expect(saveButton.classList.contains('disabled')).toBe(true);
        });
        expect(LOG.error.mock.calls.length).toEqual(0);
    });

    it('disables save button on config request rejection', async () => {
        fetch.mockRejectOnce(new Error('Rejected'));

        user.type(inputBox, validUrl);

        await waitFor(() => {
            expect(saveButton.classList.contains('disabled')).toBe(true);
        });
        expect(LOG.error.mock.calls.length).toBeGreaterThanOrEqual(1);
    });

    it('enables save button when config request is accepted', async () => {
        fetch.mockRejectOnce(!new Error('Rejected'));

        user.type(inputBox, validUrl);

        await waitFor(() => {
            expect(saveButton.classList.contains('disabled'));
        });
        expect(LOG.error.mock.calls.length).toBe(3);
    });

    it('save button is enabled with valid url', async () => {
        user.type(inputBox, validUrl);

          await waitFor(() => {
              expect(saveButton.classList.contains('enabled')).toBeDefined();
          });
     });

    it('save button is disabled with invalid url', async () => {
        user.type(inputBox, invalidUrl);
            
        await waitFor(() => {
            expect(saveButton.classList.contains('disabled')).toBeDefined();
        });

    });

     
    it('Server succesfully updates when the user hits save on a valid URL', async () => {
        fetch.mockResponseOnce(VALID_CONFIG_RESPONSE);
        user.type(inputBox, validUrl);

        await waitFor(() => {
            expect(inputBox.value).toEqual(validUrl);
        });
    });

    it('Server does not update when the user hits save on a valid URL', async () => {
        fetch.mockResponseOnce(!VALID_CONFIG_RESPONSE);
        user.type(inputBox, invalidUrl);

        await waitFor(() => {
            expect(inputBox.value).toEqual(invalidUrl);
        });
    });

 });
