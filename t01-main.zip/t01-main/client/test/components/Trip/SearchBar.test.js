import React from 'react';
import { jest } from '@jest/globals';
import SearchBar from '../../../src/components/Trip/Find/SearchBar.js';
import { render, screen, fireEvent } from '@testing-library/react';
import user from '@testing-library/user-event';
import { expect, it } from '@jest/globals';
import { MOCK_PLACES } from '../../sharedMocks.js';

describe('SearchBar', () => {
    const MOCK_RESULT = { name: 'Mollis Airport', lat: 47.08, lng: 9.06 };
  
    const setup = () => {
        const searchResults = render(<SearchBar findResults={MOCK_RESULT} findActions={{removeAll: jest.fn()}}/>);
        const input = searchResults.getByPlaceholderText("Search for an airport/heliport...");
        return {
          input,
          ...searchResults,
        }
      }

    it('tests if search icon is clicked', () => {
        render(<SearchBar findResults={MOCK_PLACES} findActions={{removeAll: jest.fn()}}/>);
        const searchButton = screen.getByTestId("search-icon");
        user.click(searchButton);
    });

    it('tests if keypress is called when Enter is clicked', () => {
        const {input} = setup();
        fireEvent.change(input, {target: {value: 'galarus'}})
        const enterKey = screen.getByPlaceholderText("Search for an airport/heliport...");
        fireEvent.keyPress(enterKey, { key: 'Enter', charCode: 13 });
        expect(input.value).toBe("galarus");
    
    });

    it('tests if search valye is being changed', () => {
        const {input} = setup()
        fireEvent.change(input, {target: {value: 'galarus'}})
        expect(input.value).toBe('galarus')
      })
   
      it('tests if clearSearch is being called', () => {
        render(<SearchBar findResults={MOCK_PLACES} findActions={{removeAll: jest.fn()}}/>);
        const clearButton = screen.getByTitle("Clear Results");
        user.click(clearButton);
      })

});