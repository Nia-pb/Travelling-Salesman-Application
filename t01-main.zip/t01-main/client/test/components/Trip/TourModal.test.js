import React from 'react';
import { render, screen, fireEvent, createEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import { beforeEach, describe, expect, it, jest } from '@jest/globals';
import { TourModal } from '../../../src/components/Trip/Itinerary/TourModal';
import userEvent from '@testing-library/user-event';
import { MOCK_PLACES } from '../../sharedMocks';

describe('TourModal', () => {

    const toggle = jest.fn();
    const showMessage = jest.fn();
    const placeActions = {
        setPlaces: jest.fn()
    };
    const serverSettings = {};
    const places = {};

    it('renders when toggled', () => {
        render(
            <TourModal 
                toggled={true} 
                toggle={toggle} 
                serverSettings={serverSettings} 
                places={places} 
                placeActions={placeActions} 
                showMessage={showMessage} />
        );

        screen.getByText("Tour");
    });

    it('does not render when not toggled', () => {
        render(
            <TourModal 
                toggled={false} 
                toggle={toggle} 
                serverSettings={serverSettings} 
                places={places} 
                placeActions={placeActions} 
                showMessage={showMessage} />
        );

        var caught = false;
        
        try {
            screen.getByText("Trip");
        } catch {
            caught = true;
        }

        expect(caught).toBe(true);
    });

    it('optimizes a trip', () => {
        render(
            <TourModal 
                toggled={true} 
                toggle={toggle} 
                serverSettings={serverSettings} 
                places={MOCK_PLACES} 
                placeActions={placeActions} 
                showMessage={showMessage} />
        );

        const button = screen.getByText("Optimize");
        userEvent.click(button);
    });

    it('toggles when the close button is clicked', () => {
        render(
            <TourModal 
                toggled={true} 
                toggle={toggle} 
                serverSettings={serverSettings} 
                places={places} 
                placeActions={placeActions} 
                showMessage={showMessage} />
        );

        const closeButton = screen.getByText("Close");

        userEvent.click(closeButton);
    });

    it('toggles when the X button is clicked', () => {
        render(
            <TourModal 
                toggled={true} 
                toggle={toggle} 
                serverSettings={serverSettings} 
                places={places} 
                placeActions={placeActions} 
                showMessage={showMessage} />
        );
        
        const xButton = screen.getByTestId("tour-modal").querySelector('[aria-label="Close"]');

        userEvent.click(xButton);
    });
});