import React from 'react';
import { render, screen, fireEvent, createEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import user from '@testing-library/user-event';
import { beforeEach, describe, expect, it, jest } from '@jest/globals';
import { LoadModal } from '../../../src/components/Trip/Itinerary/LoadModal';
import userEvent from '@testing-library/user-event';
import { act } from 'react-dom/test-utils';

describe('LoadModal', () => {
    const UPLOAD_TEXT = "Drag or click to upload file here.";

    const toggle = jest.fn();
    const showMessage = jest.fn();
    const placeActions = {
        setPlaces: jest.fn()
    };
    const distancesActions = {
        setDistances: jest.fn()
    };

    it('renders when toggled', () => {
        render(
            <LoadModal 
                toggled={true}
                toggle={toggle}
                placeActions={placeActions}
                showMessage={showMessage}
                distancesActions={distancesActions} 
            />
        );

        screen.getByText(UPLOAD_TEXT);
    });

    it('does not render when not toggled', () => {
        render(
            <LoadModal 
                toggled={false}
                toggle={toggle}
                placeActions={placeActions}
                showMessage={showMessage}
                distancesActions={distancesActions} 
            />
        );

        var caught = false;
        
        try {
            screen.getByText(UPLOAD_TEXT);
        } catch {
            caught = true;
        }

        expect(caught).toBe(true);
    });

    it('uploads a file', () => {
        render(
            <LoadModal 
                toggled={true}
                toggle={toggle}
                placeActions={placeActions}
                showMessage={showMessage}
                distancesActions={distancesActions} 
            />
        );

        const input = screen.getByTestId("dropzone-input");
        const file = new File(["test"], "test.json", {
            type: "application/json",
        });

        Object.defineProperty(input, 'files', {
            value: [file]
        });

        fireEvent.drop(input);
    });

    it('toggles when the close button is clicked', () => {
        render(
            <LoadModal 
                toggled={true}
                toggle={toggle}
                placeActions={placeActions}
                showMessage={showMessage}
                distancesActions={distancesActions} 
            />
        );

        const closeButton = screen.getByText("Close");

        userEvent.click(closeButton);
    });

    it('toggles when the X button is clicked', () => {
        render(
            <LoadModal 
                toggled={true}
                toggle={toggle}
                placeActions={placeActions}
                showMessage={showMessage}
                distancesActions={distancesActions} 
            />
        );
        
        const xButton = screen.getByTestId("load-modal").querySelector('[aria-label="Close"]');

        userEvent.click(xButton);
    });
});