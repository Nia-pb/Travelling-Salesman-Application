import React from 'react';
import '@testing-library/jest-dom';
import { render } from '@testing-library/react';
import { describe, it } from '@jest/globals';
import { Distances } from '../../../src/components/Trip/Distances/Distances';

describe('Distances', () => {
    it('renders distance when distances are set', () => {
        render(<Distances distances={[1, 1]} />);
    });

    it('Displays no distance if none present', () => {
        render(<Distances />);
    });
});