export const VALID_CONFIG_RESPONSE = JSON.stringify({
    requestType: 'config',
    serverName: 't99',
    features: ['config']
});

export const INVALID_REQUEST = JSON.stringify({
    invalid: 'this is an invalid response to fail the schema'
});

export const MOCK_PLACES = [
    { name: 'Place A', lat: 40.0, lng: 50.0 },
    { name: 'Place B', lat: 45.0, lng: 55.0 }
];

export const REVERSE_GEOCODE_RESPONSE = JSON.stringify({
    "place_id": 259127396,
    "licence": "Data © OpenStreetMap contributors, ODbL 1.0. https://osm.org/copyright",
    "osm_type": "relation",
    "osm_id": 8539568,
    "lat": "40.57066025",
    "lon": "-105.08539645568865",
    "place_rank": 30,
    "category": "amenity",
    "type": "university",
    "importance": 0.4948531325947546,
    "addresstype": "amenity",
    "name": "Colorado State University",
    "display_name": "Colorado State University, South College Avenue, Fort Collins, Larimer County, Colorado, 80525-1725, United States",
    "address": {
        "amenity": "Colorado State University",
        "road": "South College Avenue",
        "city": "Fort Collins",
        "county": "Larimer County",
        "state": "Colorado",
        "postcode": "80525-1725",
        "country": "United States",
        "country_code": "us"
    },
    "boundingbox": [
        "40.5527786",
        "40.5789122",
        "-105.0972937",
        "-105.0721817"
    ]
});

export const MOCK_TRIPFILE_JSON = "{\"places\":[{\"name\":\"Ronald Reagan Washington National Airport\",\"latitude\":\"38.852100\",\"longitude\":\"-77.037697\"},{\"name\":\"Greeley\u2013Weld County Airport\",\"latitude\":\"40.437417\",\"longitude\":\"-104.633222\"},{\"name\":\"Los Angeles International Airport\",\"latitude\":\"33.942501\",\"longitude\":\"-118.407997\"}],\"earthRadius\":6371,\"distances\":[2360,1415,3711]}";
export const MOCK_JSON_NO_DIST = "{\"places\":[{\"name\":\"Ronald Reagan Washington National Airport\",\"latitude\":\"38.852100\",\"longitude\":\"-77.037697\"},{\"name\":\"Greeley\u2013Weld County Airport\",\"latitude\":\"40.437417\",\"longitude\":\"-104.633222\"},{\"name\":\"Los Angeles International Airport\",\"latitude\":\"33.942501\",\"longitude\":\"-118.407997\"}],\"earthRadius\":6371}";
export const MOCK_TRIPFILE_CSV = '"latitude","longitude","name" \n "40.6","-105.1","place1" \n "-33.9","151.2","place2" \n "-57.9","175.2","place3"';
export const MOCK_INVALID_CSV = 'yguhygyugyuggyuyiy';
export const MOCK_DISTANCE_CSV = `"distances","latitude","longitude","name"
1034,"40.6","-105.1","place1"
785,"-33.9","151.2","place2"
1503,"-57.9","175.2","place3"`;
export const MOCK_PLACE_JSON = {"distances": [2360, 1415, 3711], "earthRadius": 6371, "places": [{"lat": 38.8521, "lng": -77.037697, "name": "Ronald Reagan Washington National Airport"}, {"lat": 40.437417, "lng": -104.633222, "name": "Greeley–Weld County Airport"}, {"lat": 33.942501, "lng": -118.407997, "name": "Los Angeles International Airport"}]};
export const MOCK_LATLNG = "{\"places\":[{\"name\":\"Ronald Reagan Washington National Airport\",\"lat\":\"38.852100\",\"lng\":\"-77.037697\"},{\"name\":\"Greeley\u2013Weld County Airport\",\"lat\":\"40.437417\",\"lng\":\"-104.633222\"},{\"name\":\"Los Angeles International Airport\",\"lat\":\"33.942501\",\"lng\":\"-118.407997\"}],\"earthRadius\":6371,\"distances\":[2360,1415,3711]}";
export const MOCK_TRIP_JSON = { places: [ { name: 'Ronald Reagan Washington National Airport', latitude: '38.852100', longitude: '-77.037697' }, { name: 'Greeley–Weld County Airport', latitude: '40.437417', longitude: '-104.633222' }, { name: 'Los Angeles International Airport', latitude: '33.942501', longitude: '-118.407997' } ], earthRadius: 6371, distances: [ 2360, 1415, 3711 ] };